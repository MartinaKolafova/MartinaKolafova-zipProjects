﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Crossword
{
    class ReadFileForCrossroad
    {

        /// <summary>
        /// List of crossword items
        /// </summary>
        public List<CrosswordItem> CrosswordItems { get; set; }

        public string FilePath { get; set; }

        public ReadFileForCrossroad(string filePath, char separator)
        {
            CrosswordItems = new List<CrosswordItem>();
            string line;
            try
            {
                using (StreamReader file = new StreamReader(filePath))
                {

                    while ((line = file.ReadLine()) != null)
                    {
                        string[] questionPlusAnswer = line.Split(separator);
                        CrosswordItems.Add(new CrosswordItem(questionPlusAnswer[0], questionPlusAnswer[1]));
                    }
                }
            }

            catch (FileNotFoundException ioEx)
            {
                Console.WriteLine(ioEx.Message);
            }
        }
    }
}
