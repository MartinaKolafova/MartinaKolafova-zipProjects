﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crossword
{
    class Program
    {
        static void Main(string[] args)
        {
            //Testing crossword
            CrosswordItem item1 = new CrosswordItem("Kdo štěká?", "Pes");
            CrosswordItem item2 = new CrosswordItem("Kdo mňouká?", "Kočka");
            CrosswordItem item3 = new CrosswordItem("Kdo kokrhá?", "Kohout");
            CrosswordItem item4 = new CrosswordItem("Kdo bučí?", "Kráva");
            CrosswordItem item5 = new CrosswordItem("Kdo kvoká?", "Slepice");
            CrosswordItem item6 = new CrosswordItem("Kdo kváká?", "Žába");
            CrosswordItem item7 = new CrosswordItem("Kdo zpívá?", "Skřivan");
            CrosswordItem item8 = new CrosswordItem("Kdo chrochtá?", "Prase");

            CreateCrossword myCrossword = new CreateCrossword("vařič");
            myCrossword.CrosswordItems.Add(item1);
            myCrossword.CrosswordItems.Add(item2);
            myCrossword.CrosswordItems.Add(item3);
            myCrossword.CrosswordItems.Add(item4);
            myCrossword.CrosswordItems.Add(item5);
            myCrossword.CrosswordItems.Add(item6);
            myCrossword.CrosswordItems.Add(item7);
            myCrossword.CrosswordItems.Add(item8);

            myCrossword.PrintInExcel("hello", false);

            myCrossword.ResetWords();

            List<CrosswordItem> crosswordItems = myCrossword.CreateListOfItemsInCrossword();
            for(int i = 0; i < crosswordItems.Count(); i++)
            {
                Console.Write(crosswordItems[i].Question);
                Console.Write(" ");
                Console.CursorLeft = 30 - crosswordItems[i].SolutionLetterIndex;
                Console.Write(crosswordItems[i].WordInCrossword);
                Console.WriteLine();

            }

            //testing from file
            ReadFileForCrossroad dataForCrossword = new ReadFileForCrossroad(@"prvky.txt", '\t');

            CreateCrossword myCrossword2 = new CreateCrossword("koronavirus");
            myCrossword2.CrosswordItems = dataForCrossword.CrosswordItems;
            myCrossword2.PrintInExcel("hello", true);

            //Console.ReadKey();
        }
    }
}
