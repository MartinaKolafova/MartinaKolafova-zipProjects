﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.IO;

namespace CrosswordGenerator
{
    /// <summary>
    /// Various tools used in the program
    /// </summary>
    public static class Tools
    {
        public static void NotImplemented()
        {
            MessageBox.Show("Tato možnost není dosud implementována", "Upozorění", MessageBoxButton.OK, MessageBoxImage.Information);
        }

    }
}
