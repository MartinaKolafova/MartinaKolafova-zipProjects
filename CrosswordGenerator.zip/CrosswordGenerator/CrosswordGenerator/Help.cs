﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrosswordGenerator
{
    public static class Help
    {
        public static List<string> ReturnHelp()
        {
            List<string> help = new List<string>();
            help.Add("Tento program generuje křížovky do Excelu, a to vždy z dvojic OTÁZKA - SLOVO DO KŘÍŽOVKY a zadané TAJENKY.");
            help.Add("Program seřadí slova v křížovce tak, aby vyšla požadovaná tajenka.");
            help.Add("Pro fungování programu je nutné mít nainstalovaný Excel.");
            help.Add("Tlačítkem 'Reset' se zruší parametry, které si program pamatuje (otázky a slova do křížovky).");
            help.Add("Do políčka 'Zadej Tajenku' se zadává výraz, který má vyjít v tajence.");
            help.Add("Tlačítko 'Načti slova z Excelu' umožňuje načíst z Excelu dvojice OTÁZKA - SLOVA DO KŘÍŽOVKY.");
            help.Add("Otázky musí být vždy v prvním sloupečku, odpověď na příslušnou otázku ve stejném řádku v druhéme sloupečku.");
            help.Add("Jakékoliv jiné rozložení povede k chybám ve vygenerované křížovce.");
            help.Add("Tlačítko 'Načti zvířecí zvuky' načte dvojice OTÁZKA - SLOVO DO KŘÍŽOVKY ve formě otázek na zvířecí zvuky.");
            help.Add("Tlačítko 'Načti chemické prvky' načte dvojice OTÁZKA - SLOVO DO KŘÍŽOVKY ve formě otázek na jména chemických prvků podle značek.");
            help.Add("Tlačítko 'Načti hlavní města' načte dvojice OTÁZKA - SLOVO DO KŘÍŽOVKY ve formě otázek na hlavní města zemí celého světa.");
            help.Add("Zaškrtávací políčko 'Zobrazit písmenka v křížovce' umožňuje zvolit, zda budou ve vygenerované křížovce zobrazena písmenka, či nikoliv (vhodné pro kontrolu).");
            help.Add("Tlačítko 'Generuj křížovku do Excelu' otevře Excel a vygeneruje do něj křížovku. Uložení je dále na uživateli.");
            help.Add("Tlačítko 'Konec' ukončí program.");
            help.Add("Tento program vyrobila Martina Kolafová, kolafova.martina@seznam.cz.");
            return help;
        }      
    }
}
