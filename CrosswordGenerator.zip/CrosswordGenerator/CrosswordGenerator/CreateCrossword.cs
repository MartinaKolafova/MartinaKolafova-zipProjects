﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;

namespace CrosswordGenerator
{
    public class CreateCrossword
    {
        /// <summary>
        /// List of crossword items
        /// </summary>
        public List<CrosswordItem> CrosswordItems { get; set; }

        /// <summary>
        /// The word, that should be result
        /// </summary>
        public string resultWord;

        /// <summary>
        /// The word, that should be result
        /// </summary>
        public string ResultWord
        {
            get
            {
                return resultWord.ToUpper();
            }
            set
            {
                resultWord = value.ToUpper();
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="resultWord">The word, that should be result of the crossword</param>
        public CreateCrossword(string resultWord)
        {
            CrosswordItems = new List<CrosswordItem>();            
            this.resultWord = resultWord;
        }

        /// <summary>
        /// Return the list to use for crossword 
        /// </summary>
        /// <returns>List of words that are used in the crossword</returns>
        public List<CrosswordItem> CreateListOfItemsInCrossword()
        {
            Shuffle(CrosswordItems);
            List<CrosswordItem> listOfUsedItems = new List<CrosswordItem>();

            //Find a word in the list for each char in resultword 
            for (int j = 0; j < ResultWord.Length; j++)
            {
                bool resultLetterWasAdded = false;

                //Go through the crossword items a search for the char form resultword
                for (int i = 0; i < CrosswordItems.Count; i++)
                {
                    //If the particular char from resultword is present
                    if (CrosswordItems[i].WordInCrossword.Contains(ResultWord[j]))
                    {
                        //If the item was not used yet 
                        if (!CrosswordItems[i].WasAlreadyUsedInThisCrossword)
                        {
                            //Change the property WasAlreadyUsedInThisCrossword of the item to true
                            CrosswordItems[i].WasAlreadyUsedInThisCrossword = true;

                            //Remember the index of the particular char in the WordInCrossword and save it as SolutionLetterIndex
                            CrosswordItems[i].SolutionLetterIndex = CrosswordItems[i].WordInCrossword.IndexOf((ResultWord[j]));

                            //Add the item to the new list
                            listOfUsedItems.Add(CrosswordItems[i]);

                            resultLetterWasAdded = true;
                            break;
                        }
                    }
                }

                //If no word contains the letter, add the letter to the listOfUsedItems without question
                if (!resultLetterWasAdded)
                {
                    listOfUsedItems.Add(new CrosswordItem(String.Empty, ResultWord[j].ToString(), true, 0));
                }
            }
            
            return listOfUsedItems;
        }

        /// <summary>
        /// If new crossword should be created, 
        /// </summary>
        public void ResetWords()
        {
            //Reset words only if CrosswordItems contains any item
            if (CrosswordItems != null)
            {
                for (int i = 0; i < CrosswordItems.Count(); i++)
                {
                    CrosswordItems[i].WasAlreadyUsedInThisCrossword = false;
                    CrosswordItems[i].SolutionLetterIndex = -1;
                }
            }
        }

        /// <summary>
        /// Find the maximum SolutionLetterIndex in the CrosswordItems
        /// </summary>
        /// <returns>Maximum SolutionLetterIndex</returns>
        public int FindTheHighestIndexOfResult()
        {
            if (CrosswordItems.Count() > 0)
            {
                return CrosswordItems.Max(x => x.SolutionLetterIndex);
            }
            else
            {
                return 0;
            }
        }


        /// <summary>
        /// Print the crossword in excel
        /// </summary>
        /// <param name="fileName">Name of file, not used yet</param>
        /// <param name="areWordsVisible">If true, words are visible, if false, words are not visible (the crossword is ready to use)</param>
        public void PrintInExcel(string _fileName, bool areWordsVisible)
        {
            ResetWords();
            Application excel = new Application
            {
                Visible = true
            };

            _Workbook xlWorkbook = excel.Workbooks.Add();
            Range cell = excel.ActiveCell;

            List<CrosswordItem> wordsInCrossWord = CreateListOfItemsInCrossword();

            for (int i = 0; i < wordsInCrossWord.Count; i++)
            {
                cell.Value = wordsInCrossWord[i].Question;
                cell = cell.Offset[0, 1 + FindTheHighestIndexOfResult() - wordsInCrossWord[i].SolutionLetterIndex];
                for (int j = 0; j < wordsInCrossWord[i].WordInCrossword.Length; j++)
                {
                    if (areWordsVisible || wordsInCrossWord[i].WordInCrossword.Length == 1)
                    {
                        cell.Value = wordsInCrossWord[i].WordInCrossword[j].ToString();
                    }

                    cell.BorderAround(XlLineStyle.xlContinuous, XlBorderWeight.xlThin, XlColorIndex.xlColorIndexAutomatic);
                    if (j == wordsInCrossWord[i].SolutionLetterIndex)
                    {
                        cell.BorderAround(XlLineStyle.xlContinuous, XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);
                    }
                    cell = cell.Next;
                }
                cell = cell.Offset[1, -wordsInCrossWord[i].WordInCrossword.Length - (FindTheHighestIndexOfResult() - wordsInCrossWord[i].SolutionLetterIndex) - 1];
            }
        }

        //trida otevre excel 
        //aby se to nezetsovalo - leva a horni kotvicka
        //okno minimalni/maximalni

        public void ReadExcelFile(string fileName)
        {
            string question = String.Empty;
            string answer = String.Empty;

            Application excel = new Application
            {
                Visible = false
            };            

        Workbook xlWorkbook = excel.Workbooks.Open(fileName);
        Worksheet wkSheet = xlWorkbook.Worksheets[1];
        Range cell = wkSheet.Cells[1, 1];

            while (cell.Value != null)
            {
                question = cell.Value;
                cell = cell.Offset[0, 1];
                if (cell.Value != null)
                {
                    answer = cell.Value.Trim();
                    CrosswordItems.Add(new CrosswordItem(question, answer));
                }
                cell = cell.Offset[1, -1];               
            }
            xlWorkbook.Close();
            excel.Quit();
            for(int i = 0; i < CrosswordItems.Count(); i++)
            {
                CrosswordItems[i].WordInCrossword.Trim(' ');
                CrosswordItems[i].WordInCrossword.Trim();
                CrosswordItems[i].WordInCrossword.TrimStart();
            }
        }

        public void DeleteThisCrossroad()
        {
            CrosswordItems.Clear();
        }

        public void AddQuestionCities()
        {
            CrosswordItems.Add(new CrosswordItem("Afghánistán", "Kábul"));
            CrosswordItems.Add(new CrosswordItem("Albánie", "Tirana"));
            CrosswordItems.Add(new CrosswordItem("Alžírsko", "Alžír"));
            CrosswordItems.Add(new CrosswordItem("Andorra", "Andorra la Vella"));
            CrosswordItems.Add(new CrosswordItem("Angola", "Luanda"));
            CrosswordItems.Add(new CrosswordItem("Barbuda a Antigua", "Saint John's"));
            CrosswordItems.Add(new CrosswordItem("Argentina", "Buenos Aires"));
            CrosswordItems.Add(new CrosswordItem("Arménie", "Jerevan"));
            CrosswordItems.Add(new CrosswordItem("Austrálie", "Canberra"));
            CrosswordItems.Add(new CrosswordItem("Ázerbájdžán", "Baku"));
            CrosswordItems.Add(new CrosswordItem("Bahamy", "Nassau"));
            CrosswordItems.Add(new CrosswordItem("Bahrajn", "Manáma"));
            CrosswordItems.Add(new CrosswordItem("Bangladéš", "Dháka"));
            CrosswordItems.Add(new CrosswordItem("Barbados", "Bridgetown"));
            CrosswordItems.Add(new CrosswordItem("Belgie", "Brusel"));
            CrosswordItems.Add(new CrosswordItem("Belize", "Belmopan"));
            CrosswordItems.Add(new CrosswordItem("Bělorusko", "Minsk"));
            CrosswordItems.Add(new CrosswordItem("Benin", "Porto"));
            CrosswordItems.Add(new CrosswordItem("Novo", "Bhútán"));
            CrosswordItems.Add(new CrosswordItem("Thimbú", "Bolívie"));
            CrosswordItems.Add(new CrosswordItem("Sucre", "Bosna a Hercegovina"));
            CrosswordItems.Add(new CrosswordItem("Sarajevo", "Botswana"));
            CrosswordItems.Add(new CrosswordItem("Gaborone", "Brazílie"));
            CrosswordItems.Add(new CrosswordItem("Brasília", "Brunej"));
            CrosswordItems.Add(new CrosswordItem("Bandar Seri Begawan", "Bulharsko"));
            CrosswordItems.Add(new CrosswordItem("Sofia", "Burkina Faso"));
            CrosswordItems.Add(new CrosswordItem("Ouagadougou", "Burundi"));
            CrosswordItems.Add(new CrosswordItem("Gitega", "Čad N'Djamena"));
            CrosswordItems.Add(new CrosswordItem("Černá Hora", "Podgorica"));
            CrosswordItems.Add(new CrosswordItem("Česko", "Praha"));
            CrosswordItems.Add(new CrosswordItem("Čína", "Peking"));
            CrosswordItems.Add(new CrosswordItem("Dánsko", "Kodaň"));
            CrosswordItems.Add(new CrosswordItem("Konžská demokratická republika", "Kinshasa"));
            CrosswordItems.Add(new CrosswordItem("Dominika", "Roseau"));
            CrosswordItems.Add(new CrosswordItem("Dominikánská republika", "Santo Domingo"));
            CrosswordItems.Add(new CrosswordItem("Džibutsko", "Džibuti"));
            CrosswordItems.Add(new CrosswordItem("Egypt", "Káhira"));
            CrosswordItems.Add(new CrosswordItem("Ekvádor", "Quito"));
            CrosswordItems.Add(new CrosswordItem("Eritrea", "Asmara"));
            CrosswordItems.Add(new CrosswordItem("Estonsko", "Tallinn"));
            CrosswordItems.Add(new CrosswordItem("Etiopie", "Addis Abeba"));
            CrosswordItems.Add(new CrosswordItem("Fidži", "Suva"));
            CrosswordItems.Add(new CrosswordItem("Filipíny", "Manila"));
            CrosswordItems.Add(new CrosswordItem("Finsko", "Helsinki"));
            CrosswordItems.Add(new CrosswordItem("Francie", "Paříž"));
            CrosswordItems.Add(new CrosswordItem("Gabon", "Libreville"));
            CrosswordItems.Add(new CrosswordItem("Gambie", "Banjul"));
            CrosswordItems.Add(new CrosswordItem("Ghana", "Akkra"));
            CrosswordItems.Add(new CrosswordItem("Grenada", "Saint George's"));
            CrosswordItems.Add(new CrosswordItem("Gruzie", "Tbilisi"));
            CrosswordItems.Add(new CrosswordItem("Guatemala", "Ciudad de Guatemala"));
            CrosswordItems.Add(new CrosswordItem("Guinea", "Konakry"));
            CrosswordItems.Add(new CrosswordItem("Guinea - Bissau", "Bissau"));
            CrosswordItems.Add(new CrosswordItem("Guyana", "Georgetown"));
            CrosswordItems.Add(new CrosswordItem("Haiti", "Port-au-Prince"));
            CrosswordItems.Add(new CrosswordItem("Honduras", "Tegucigalpa"));
            CrosswordItems.Add(new CrosswordItem("Chile", "Santiago de Chile"));
            CrosswordItems.Add(new CrosswordItem("Chorvatsko", "Záhřeb"));
            CrosswordItems.Add(new CrosswordItem("Indie", "Nové Dillí"));
            CrosswordItems.Add(new CrosswordItem("Indonésie", "Jakarta"));
            CrosswordItems.Add(new CrosswordItem("Irák", "Bagdád"));
            CrosswordItems.Add(new CrosswordItem("Írán", "Teherán"));
            CrosswordItems.Add(new CrosswordItem("Irsko", "Dublin"));
            CrosswordItems.Add(new CrosswordItem("Island", "Reykjavík"));
            CrosswordItems.Add(new CrosswordItem("Itálie", "Řím"));
            CrosswordItems.Add(new CrosswordItem("Izrael", "Jeruzalém"));
            CrosswordItems.Add(new CrosswordItem("Jamajka", "Kingston"));
            CrosswordItems.Add(new CrosswordItem("Japonsko", "Tokio"));
            CrosswordItems.Add(new CrosswordItem("Jemen", "San'á"));
            CrosswordItems.Add(new CrosswordItem("Jihoafrická republika", "Pretorie"));
            CrosswordItems.Add(new CrosswordItem("Jižní Korea", "Soul"));
            CrosswordItems.Add(new CrosswordItem("Jižní Súdán", "Džuba"));
            CrosswordItems.Add(new CrosswordItem("Jordánsko", "Ammán"));
            CrosswordItems.Add(new CrosswordItem("Kambodža", "Phnompenh"));
            CrosswordItems.Add(new CrosswordItem("Kamerun", "Yaoundé"));
            CrosswordItems.Add(new CrosswordItem("Kanada", "Ottawa"));
            CrosswordItems.Add(new CrosswordItem("Kapverdy", "Praia"));
            CrosswordItems.Add(new CrosswordItem("Katar", "Dauhá"));
            CrosswordItems.Add(new CrosswordItem("Kazachstán", "Nur-Sultan"));
            CrosswordItems.Add(new CrosswordItem("Keňa", "Nairobi"));
            CrosswordItems.Add(new CrosswordItem("Kiribati", "Tarawa"));
            CrosswordItems.Add(new CrosswordItem("Kolumbie", "Bogotá"));
            CrosswordItems.Add(new CrosswordItem("Komory", "Moroni"));
            CrosswordItems.Add(new CrosswordItem("Kosovo", "Priština"));
            CrosswordItems.Add(new CrosswordItem("Kostarika", "San José"));
            CrosswordItems.Add(new CrosswordItem("Kuba", "Havana"));
            CrosswordItems.Add(new CrosswordItem("Kuvajt", "Kuvajt"));
            CrosswordItems.Add(new CrosswordItem("Kypr", "Nikósie"));
            CrosswordItems.Add(new CrosswordItem("Kyrgyzstán", "Biškek"));
            CrosswordItems.Add(new CrosswordItem("Laos", "Vientiane"));
            CrosswordItems.Add(new CrosswordItem("Lesotho", "Maseru"));
            CrosswordItems.Add(new CrosswordItem("Libanon", "Bejrút"));
            CrosswordItems.Add(new CrosswordItem("Libérie", "Monrovia"));
            CrosswordItems.Add(new CrosswordItem("Libye", "Tripolis"));
            CrosswordItems.Add(new CrosswordItem("Lichtenštejnsko", "Vaduz"));
            CrosswordItems.Add(new CrosswordItem("Litva", "Vilnius"));
            CrosswordItems.Add(new CrosswordItem("Lotyšsko", "Riga"));
            CrosswordItems.Add(new CrosswordItem("Lucembursko", "Lucemburk"));
            CrosswordItems.Add(new CrosswordItem("Madagaskar", "Antananarivo"));
            CrosswordItems.Add(new CrosswordItem("Maďarsko", "Budapešť"));
            CrosswordItems.Add(new CrosswordItem("Malajsie", "Kuala Lumpur"));
            CrosswordItems.Add(new CrosswordItem("Malawi", "Lilongwe"));
            CrosswordItems.Add(new CrosswordItem("Maledivy", "Male"));
            CrosswordItems.Add(new CrosswordItem("Mali", "Bamako"));
            CrosswordItems.Add(new CrosswordItem("Malta", "Valletta"));
            CrosswordItems.Add(new CrosswordItem("Maroko", "Rabat"));
            CrosswordItems.Add(new CrosswordItem("Marshallovy ostrovy", "Majuro"));
            CrosswordItems.Add(new CrosswordItem("Mauricius", "Port Louis"));
            CrosswordItems.Add(new CrosswordItem("Mauritánie", "Nuakšott"));
            CrosswordItems.Add(new CrosswordItem("Mexiko", "Ciudad de México"));
            CrosswordItems.Add(new CrosswordItem("Mikronésie", "Palikir"));
            CrosswordItems.Add(new CrosswordItem("Moldavsko", "Kišiněv"));
            CrosswordItems.Add(new CrosswordItem("Monako", "Monaco-Ville"));
            CrosswordItems.Add(new CrosswordItem("Mongolsko", "Ulánbátar"));
            CrosswordItems.Add(new CrosswordItem("Mosambik", "Maputo"));
            CrosswordItems.Add(new CrosswordItem("Myanmar(Barma)", "Neipyijto"));
            CrosswordItems.Add(new CrosswordItem("Namibie", "Windhoek"));
            CrosswordItems.Add(new CrosswordItem("Nauru", "Yaren"));
            CrosswordItems.Add(new CrosswordItem("Německo", "Berlín"));
            CrosswordItems.Add(new CrosswordItem("Nepál", "Káthmándú"));
            CrosswordItems.Add(new CrosswordItem("Niger", "Niamey"));
            CrosswordItems.Add(new CrosswordItem("Nigérie", "Abuja"));
            CrosswordItems.Add(new CrosswordItem("Nikaragua", "Managua"));
            CrosswordItems.Add(new CrosswordItem("Nizozemsko", "Amsterdam"));
            CrosswordItems.Add(new CrosswordItem("Norsko", "Oslo"));
            CrosswordItems.Add(new CrosswordItem("Nový Zéland", "Wellington"));
            CrosswordItems.Add(new CrosswordItem("Omán", "Maskat"));
            CrosswordItems.Add(new CrosswordItem("Pákistán", "Islámábád"));
            CrosswordItems.Add(new CrosswordItem("Palau", "Ngerulmud"));
            CrosswordItems.Add(new CrosswordItem("Panama", "Ciudad de Panamá"));
            CrosswordItems.Add(new CrosswordItem("Papua Nová Guinea", "Port Moresby"));
            CrosswordItems.Add(new CrosswordItem("Paraguay", "Asunción"));
            CrosswordItems.Add(new CrosswordItem("Peru", "Lima"));
            CrosswordItems.Add(new CrosswordItem("Pobřeží slonoviny", "Yamoussoukro"));
            CrosswordItems.Add(new CrosswordItem("Polsko", "Varšava"));
            CrosswordItems.Add(new CrosswordItem("Portugalsko", "Lisabon"));
            CrosswordItems.Add(new CrosswordItem("Rakousko", "Vídeň"));
            CrosswordItems.Add(new CrosswordItem("Konžská republika", "Brazzaville"));
            CrosswordItems.Add(new CrosswordItem("Rovníková Guinea", "Malabo"));
            CrosswordItems.Add(new CrosswordItem("Rumunsko", "Bukurešť"));
            CrosswordItems.Add(new CrosswordItem("Rusko", "Moskva"));
            CrosswordItems.Add(new CrosswordItem("Rwanda", "Kigali"));
            CrosswordItems.Add(new CrosswordItem("Řecko", "Atény"));
            CrosswordItems.Add(new CrosswordItem("Salvador", "San Salvador"));
            CrosswordItems.Add(new CrosswordItem("Samoa", "Apia"));
            CrosswordItems.Add(new CrosswordItem("San Marino", "San Marino"));
            CrosswordItems.Add(new CrosswordItem("Saúdská Arábie", "Rijád"));
            CrosswordItems.Add(new CrosswordItem("Senegal", "Dakar"));
            CrosswordItems.Add(new CrosswordItem("Severní Korea", "Pchjongjang"));
            CrosswordItems.Add(new CrosswordItem("Severní Makedonie", "Skopje"));
            CrosswordItems.Add(new CrosswordItem("Seychely", "Victoria"));
            CrosswordItems.Add(new CrosswordItem("Sierra Leone", "Freetown"));
            CrosswordItems.Add(new CrosswordItem("Singapur", "Singapur"));
            CrosswordItems.Add(new CrosswordItem("Slovensko", "Bratislava"));
            CrosswordItems.Add(new CrosswordItem("Slovinsko", "Lublaň"));
            CrosswordItems.Add(new CrosswordItem("Somálsko", "Mogadišo"));
            CrosswordItems.Add(new CrosswordItem("Spojené arabské emiráty", "Abú Zabí"));
            CrosswordItems.Add(new CrosswordItem("Velká Británie", "Londýn"));
            CrosswordItems.Add(new CrosswordItem("Spojené státy americké", "Washington"));
            CrosswordItems.Add(new CrosswordItem("Srbsko", "Bělehrad"));
            CrosswordItems.Add(new CrosswordItem("Středoafrická republika", "Bangui"));
            CrosswordItems.Add(new CrosswordItem("Súdán", "Chartúm"));
            CrosswordItems.Add(new CrosswordItem("Surinam", "Paramaribo"));
            CrosswordItems.Add(new CrosswordItem("Svatá Lucie", "Castries"));
            CrosswordItems.Add(new CrosswordItem("Svatý Kryštof a Nevis", "Basseterre"));
            CrosswordItems.Add(new CrosswordItem("Svatý Tomáš a Princův ostrov", "Sao Tomé"));
            CrosswordItems.Add(new CrosswordItem("Svatý Vincenc a Grenadiny", "Kingstown"));
            CrosswordItems.Add(new CrosswordItem("Svazijsko", "Mbabane"));
            CrosswordItems.Add(new CrosswordItem("Sýrie", "Damašek"));
            CrosswordItems.Add(new CrosswordItem("Šalomounovy ostrovy", "Honiara"));
            CrosswordItems.Add(new CrosswordItem("Španělsko", "Madrid"));
            CrosswordItems.Add(new CrosswordItem("Srí Lanka", "Šrí Džajavardanapura Kotte"));
            CrosswordItems.Add(new CrosswordItem("Švédsko", "Stockholm"));
            CrosswordItems.Add(new CrosswordItem("Švýcarsko", "Bern"));
            CrosswordItems.Add(new CrosswordItem("Tádžikistán", "Dušanbe"));
            CrosswordItems.Add(new CrosswordItem("Tanzanie", "Dodoma"));
            CrosswordItems.Add(new CrosswordItem("Thajsko", "Bangkok"));
            CrosswordItems.Add(new CrosswordItem("Tchaj - wan", "Tchaj-pej"));
            CrosswordItems.Add(new CrosswordItem("Togo", "Lomé"));
            CrosswordItems.Add(new CrosswordItem("Tonga", "Nuku'alofa"));
            CrosswordItems.Add(new CrosswordItem("Tobago a Trinidad", "Port of Spain"));
            CrosswordItems.Add(new CrosswordItem("Tunisko", "Tunis"));
            CrosswordItems.Add(new CrosswordItem("Turecko", "Ankara"));
            CrosswordItems.Add(new CrosswordItem("Turkmenistán", "Ašchabad"));
            CrosswordItems.Add(new CrosswordItem("Tuvalu", "Funafuti"));
            CrosswordItems.Add(new CrosswordItem("Uganda", "Kampala"));
            CrosswordItems.Add(new CrosswordItem("Ukrajina", "Kyjev"));
            CrosswordItems.Add(new CrosswordItem("Uruguay", "Montevideo"));
            CrosswordItems.Add(new CrosswordItem("Uzbekistán", "Taškent"));
            CrosswordItems.Add(new CrosswordItem("Vanuatu", "Port Vila"));
            CrosswordItems.Add(new CrosswordItem("Vatikán", "Vatikán"));
            CrosswordItems.Add(new CrosswordItem("Venezuela", "Caracas"));
            CrosswordItems.Add(new CrosswordItem("Vietnam", "Hanoj"));
            CrosswordItems.Add(new CrosswordItem("Východní Timor", "Dili"));
            CrosswordItems.Add(new CrosswordItem("Zambie", "Lusaka"));

        }

        public void AddQuestionsAnimals()
        {
            CrosswordItems.Add(new CrosswordItem("Kdo štěká?", "Pes"));
            CrosswordItems.Add(new CrosswordItem("Kdo mňouká?", "Kočka"));
            CrosswordItems.Add(new CrosswordItem("Kdo kokrhá?", "Kohout"));
            CrosswordItems.Add(new CrosswordItem("Kdo bučí?", "Kráva"));
            CrosswordItems.Add(new CrosswordItem("Kdo kvoká?", "Slepice"));
            CrosswordItems.Add(new CrosswordItem("Kdo kváká?", "Žába"));
            CrosswordItems.Add(new CrosswordItem("Kdo zpívá?", "Skřivan"));
            CrosswordItems.Add(new CrosswordItem("Kdo chrochtá?", "Prase"));
            CrosswordItems.Add(new CrosswordItem("Kdo hýká?", "Osel"));
            CrosswordItems.Add(new CrosswordItem("Kdo houká?", "Sova"));            
        }

        public void AddQuestionsElements()
        {
            CrosswordItems.Add(new CrosswordItem("H", "vodík"));
            CrosswordItems.Add(new CrosswordItem("He", "helium"));
            CrosswordItems.Add(new CrosswordItem("Li", "lithium"));
            CrosswordItems.Add(new CrosswordItem("Be", "beryllium"));
            CrosswordItems.Add(new CrosswordItem("B", "bor"));
            CrosswordItems.Add(new CrosswordItem("C", "uhlík"));
            CrosswordItems.Add(new CrosswordItem("N", "dusík"));
            CrosswordItems.Add(new CrosswordItem("O", "kyslík"));
            CrosswordItems.Add(new CrosswordItem("F", "fluor"));
            CrosswordItems.Add(new CrosswordItem("Ne", "neon"));
            CrosswordItems.Add(new CrosswordItem("Na", "sodík"));
            CrosswordItems.Add(new CrosswordItem("Mg", "hořčík"));
            CrosswordItems.Add(new CrosswordItem("Al", "hliník"));
            CrosswordItems.Add(new CrosswordItem("Si", "křemík"));
            CrosswordItems.Add(new CrosswordItem("P", "fosfor"));
            CrosswordItems.Add(new CrosswordItem("S", "síra"));
            CrosswordItems.Add(new CrosswordItem("Cl", "chlor"));
            CrosswordItems.Add(new CrosswordItem("Ar", "argon"));
            CrosswordItems.Add(new CrosswordItem("K", "draslík"));
            CrosswordItems.Add(new CrosswordItem("Ca", "vápník"));
            CrosswordItems.Add(new CrosswordItem("Sc", "skandium"));
            CrosswordItems.Add(new CrosswordItem("Ti", "titan"));
            CrosswordItems.Add(new CrosswordItem("V", "vanad"));
            CrosswordItems.Add(new CrosswordItem("Cr", "chrom"));
            CrosswordItems.Add(new CrosswordItem("Mn", "mangan"));
            CrosswordItems.Add(new CrosswordItem("Fe", "železo"));
            CrosswordItems.Add(new CrosswordItem("Co", "kobalt"));
            CrosswordItems.Add(new CrosswordItem("Ni", "nikl"));
            CrosswordItems.Add(new CrosswordItem("Cu", "měď"));
            CrosswordItems.Add(new CrosswordItem("Zn", "zinek"));
            CrosswordItems.Add(new CrosswordItem("Ga", "gallium"));
            CrosswordItems.Add(new CrosswordItem("Ge", "germanium"));
            CrosswordItems.Add(new CrosswordItem("As", "arsen"));
            CrosswordItems.Add(new CrosswordItem("Se", "selen"));
            CrosswordItems.Add(new CrosswordItem("Br", "brom"));
            CrosswordItems.Add(new CrosswordItem("Kr", "krypton"));
            CrosswordItems.Add(new CrosswordItem("Rb", "rubidium"));
            CrosswordItems.Add(new CrosswordItem("Sr", "stroncium"));            
            CrosswordItems.Add(new CrosswordItem("Y", "yttrium"));
            CrosswordItems.Add(new CrosswordItem("Zr", "zirkonium"));
            CrosswordItems.Add(new CrosswordItem("Nb", "niob"));
            CrosswordItems.Add(new CrosswordItem("Mo", "molybden"));
            CrosswordItems.Add(new CrosswordItem("Tc", "technecium"));
            CrosswordItems.Add(new CrosswordItem("Ru", "ruthenium"));
            CrosswordItems.Add(new CrosswordItem("Rh", "rhodium"));
            CrosswordItems.Add(new CrosswordItem("Pd", "palladium"));
            CrosswordItems.Add(new CrosswordItem("Ag", "stříbro"));
            CrosswordItems.Add(new CrosswordItem("Cd", "kadmium"));
            CrosswordItems.Add(new CrosswordItem("In", "indium"));
            CrosswordItems.Add(new CrosswordItem("Sn", "cín"));
            CrosswordItems.Add(new CrosswordItem("Sb", "antimon"));
            CrosswordItems.Add(new CrosswordItem("Te", "tellur"));
            CrosswordItems.Add(new CrosswordItem("I", "jod"));
            CrosswordItems.Add(new CrosswordItem("Xe", "xenon"));
            CrosswordItems.Add(new CrosswordItem("Cs", "cesium"));
            CrosswordItems.Add(new CrosswordItem("Ba", "baryum"));
            CrosswordItems.Add(new CrosswordItem("La", "lanthan"));
            CrosswordItems.Add(new CrosswordItem("Ce", "cer"));
            CrosswordItems.Add(new CrosswordItem("Pr", "praseodym"));
            CrosswordItems.Add(new CrosswordItem("Nd", "neodym"));
            CrosswordItems.Add(new CrosswordItem("Pm", "promethium"));
            CrosswordItems.Add(new CrosswordItem("Sm", "samarium"));
            CrosswordItems.Add(new CrosswordItem("Eu", "europium"));
            CrosswordItems.Add(new CrosswordItem("Gd", "gadolinium"));
            CrosswordItems.Add(new CrosswordItem("Tb", "terbium"));
            CrosswordItems.Add(new CrosswordItem("Dy", "dysprosium"));
            CrosswordItems.Add(new CrosswordItem("Ho", "holmium"));
            CrosswordItems.Add(new CrosswordItem("Er", "erbium"));
            CrosswordItems.Add(new CrosswordItem("Tm", "thulium"));
            CrosswordItems.Add(new CrosswordItem("Yb", "ytterbium"));
            CrosswordItems.Add(new CrosswordItem("Lu", "lutecium"));
            CrosswordItems.Add(new CrosswordItem("Hf", "hafnium"));
            CrosswordItems.Add(new CrosswordItem("Ta", "tantal"));
            CrosswordItems.Add(new CrosswordItem("W", "wolfram"));
            CrosswordItems.Add(new CrosswordItem("Re", "rhenium"));
            CrosswordItems.Add(new CrosswordItem("Os", "osmium"));
            CrosswordItems.Add(new CrosswordItem("Ir", "iridium"));
            CrosswordItems.Add(new CrosswordItem("Pt", "platina"));
            CrosswordItems.Add(new CrosswordItem("Au", "zlato"));
            CrosswordItems.Add(new CrosswordItem("Hg", "rtuť"));
            CrosswordItems.Add(new CrosswordItem("Tl", "thallium"));
            CrosswordItems.Add(new CrosswordItem("Pb", "olovo"));
            CrosswordItems.Add(new CrosswordItem("Bi", "bismut"));
            CrosswordItems.Add(new CrosswordItem("Po", "polonium"));
            CrosswordItems.Add(new CrosswordItem("At", "astat"));
            CrosswordItems.Add(new CrosswordItem("Rn", "radon"));
            CrosswordItems.Add(new CrosswordItem("Fr", "francium"));
            CrosswordItems.Add(new CrosswordItem("Ra", "radium"));
            CrosswordItems.Add(new CrosswordItem("Ac", "aktinium"));
            CrosswordItems.Add(new CrosswordItem("Th", "thorium"));
            CrosswordItems.Add(new CrosswordItem("Pa", "protaktinium"));
            CrosswordItems.Add(new CrosswordItem("U", "uran"));
            CrosswordItems.Add(new CrosswordItem("Np", "neptunium"));
            CrosswordItems.Add(new CrosswordItem("Pu", "plutonium"));
            CrosswordItems.Add(new CrosswordItem("Am", "americium"));
            CrosswordItems.Add(new CrosswordItem("Cm", "curium"));
            CrosswordItems.Add(new CrosswordItem("Bk", "berkelium"));
            CrosswordItems.Add(new CrosswordItem("Cf", "kalifornium"));
            CrosswordItems.Add(new CrosswordItem("Es", "einsteinium"));
            CrosswordItems.Add(new CrosswordItem("Fm", "fermium"));
            CrosswordItems.Add(new CrosswordItem("Md", "mendelevium"));
            CrosswordItems.Add(new CrosswordItem("No", "nobelium"));
            CrosswordItems.Add(new CrosswordItem("Lr", "lawrencium"));
            CrosswordItems.Add(new CrosswordItem("Rf", "rutherfordium"));
            CrosswordItems.Add(new CrosswordItem("Db", "dubnium"));
            CrosswordItems.Add(new CrosswordItem("Sg", "seaborgium"));
            CrosswordItems.Add(new CrosswordItem("Bh", "bohrium"));
            CrosswordItems.Add(new CrosswordItem("Hs", "hassium"));
            CrosswordItems.Add(new CrosswordItem("Mt", "meitnerium"));
            CrosswordItems.Add(new CrosswordItem("Ds", "darmstadtium"));
            CrosswordItems.Add(new CrosswordItem("Rg", "roentgenium"));
            CrosswordItems.Add(new CrosswordItem("Cn", "kopernicium"));
            CrosswordItems.Add(new CrosswordItem("Nh", "nihonium"));
            CrosswordItems.Add(new CrosswordItem("Fl", "flerovium"));
            CrosswordItems.Add(new CrosswordItem("Mc", "moscovium"));
            CrosswordItems.Add(new CrosswordItem("Lv", "livermorium"));
            CrosswordItems.Add(new CrosswordItem("Ts", "tennessin"));
            CrosswordItems.Add(new CrosswordItem("Og", "oganesson"));
        }

        private static Random rng = new Random();

        public static void Shuffle(List<CrosswordItem> list)
        {
            int n = list.Count();
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                CrosswordItem value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }
    }
}
