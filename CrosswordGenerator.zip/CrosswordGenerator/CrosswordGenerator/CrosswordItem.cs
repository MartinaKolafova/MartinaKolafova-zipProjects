﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrosswordGenerator
{
    public class CrosswordItem
    {
        /// <summary>
        /// The question related to the word in crossword
        /// </summary>
        public string Question { get; set; }

        /// <summary>
        /// The word in crossword
        /// </summary>
        public string WordInCrossword { get; set; }

        /// <summary>
        /// Was this item already used in the crossword
        /// </summary>
        public bool WasAlreadyUsedInThisCrossword { get; set; }

        /// <summary>
        /// What is the indec of soultion letter in the word?
        /// </summary>
        public int SolutionLetterIndex { get; set; } = -1;

        /// <summary>
        /// Constructor of the crossword item
        /// </summary>
        /// <param name="question">Question to be asked for this crossword</param>
        /// <param name="wordInCrossword">Word in crossword realted to the question</param>
        public CrosswordItem(string question, string wordInCrossword)
        {
            Question = question;
            WordInCrossword = wordInCrossword.ToUpper();
            WasAlreadyUsedInThisCrossword = false;
        }

        public CrosswordItem(string question, string wordInCrossword, bool wasAlreadyUsed, int solutionLetterIndex)
        {
            Question = question;
            WordInCrossword = wordInCrossword;
            WasAlreadyUsedInThisCrossword = wasAlreadyUsed;
            SolutionLetterIndex = solutionLetterIndex;
        }

        /// <summary>
        /// Empty crossword item
        /// </summary>
        public CrosswordItem()
        {
            Question = String.Empty;
            WordInCrossword = String.Empty;
            WasAlreadyUsedInThisCrossword = false;
        }
    }
}
