﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.IO;


namespace CrosswordGenerator
{

    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// The crossword
        /// </summary>
        public static CreateCrossword myCrossword = new CreateCrossword("Tajenka");

        public MainWindow()
        {
            InitializeComponent();
            myCrossword.ResultWord = Tajenka.Text;
        }                

        private void Tajenka_TextChanged(object sender, TextChangedEventArgs e)
        {
            myCrossword.ResultWord = Tajenka.Text;
        }

        private void End_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            myCrossword.DeleteThisCrossroad();
        }

        private void ReadFromFileButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog readFromXLSXopenFileDialog = new OpenFileDialog()
            {
                DefaultExt = ".xlsx",
                Title = "Otevřít"
            };
            if (readFromXLSXopenFileDialog.ShowDialog() == true)
            {
                myCrossword.ReadExcelFile(readFromXLSXopenFileDialog.InitialDirectory + readFromXLSXopenFileDialog.FileName);
            }

        }

        private void AnimalSoundsButton_Click(object sender, RoutedEventArgs e)
        {
            myCrossword.AddQuestionsAnimals();
        }

        private void ElementsButton_Click(object sender, RoutedEventArgs e)
        {
            myCrossword.AddQuestionsElements();
        }

        private void InExcelButton_Click(object sender, RoutedEventArgs e)
        {
            bool isChecked = (bool)WordsVisible.IsChecked;            
            myCrossword.PrintInExcel("name", isChecked);
        }

        private void CitiesButton_Click(object sender, RoutedEventArgs e)
        {
            myCrossword.AddQuestionCities();
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            HelpWindow help = new HelpWindow();
            help.Show();
        }
    }
}
