﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;
using System.IO;

namespace PictureCrossword
{
    /// <summary>
    /// Print the whole treasure hunt based on crossword in Word
    /// </summary>
    class PrintWholeTreasureHuntInWord
    {
        /// <summary>
        /// The words in crossword
        /// </summary>
        public List<string> AvailableWords { get; set; }

        public List<CrosswordItem> WordsInCrossword { get; set; }

        public string NameOfDirectoryWithPictures { get; set; }

        public CreateCrossword WordCrossword { get; set; }

        /// <summary>
        /// he length of table  with the crossword 
        /// </summary>
        public int lengthOfTableWithCrossword;

        //new word app
        Application Word { get; set; }

        /// <summary>
        /// Is the Word App visible?
        /// </summary>
        public bool Visibility { get; set; }

        /// <summary>
        /// Where to save the files with crosswords
        /// </summary>
        public string DirectoryToSave { get; set; }

        /// <summary>
        /// the name of reult file
        /// </summary>
        private string NameOfResultFile { get; set; }

        /// <summary>
        /// The name of directory with Title pages
        /// </summary>
        public string NameOfDirectoryWithTitlePages { get; set; }

        /// <summary>
        /// List of files with the pages, that should be before crossword
        /// </summary>
        public List<string> AllFilesWithTitlePages { get; set; }

        /// <summary>
        /// The name of directory with Final pages
        /// </summary>
        public string NameOfDirectoryWithFinalPages { get; set; }

        /// <summary>
        /// List of files with the pages, that should be after crosswords and pictures with clues 
        /// </summary>
        public List<string> AllFilesWithFinalPages { get; set; }

        /// <summary>
        /// Is the text in Crossword visible?
        /// </summary>
        public bool VisibilityOfText {get; set;}


    /// <summary>
    /// The length of table  with the crossword
    /// First column = numbers
    /// Crossword starts from second column
    /// </summary>
    public int LengthOfTableWithCrossword
        {
            get
            {
                //The maximum lengthe of a word after soultion index
                int maxAfterSolutionIndex = WordsInCrossword.Max(x => x.WordInCrossword.Length - (x.SolutionLetterIndex + 1));
                //the maximum solution letter index + 1 
                int maxLettersBeforeSolutionIndex = WordsInCrossword.Max(x => x.SolutionLetterIndex) + 1;
                //The maximum length of the table is the maximum number of letter before the solution letter index + the maximme after solution letterindex + 1 
                lengthOfTableWithCrossword = maxAfterSolutionIndex + maxLettersBeforeSolutionIndex + 1;
                return lengthOfTableWithCrossword;
            }
            set
            {
                lengthOfTableWithCrossword = value;
            }

        }        

        public int NumberOfRowsInCrosswordTable { get; set; }


        Document Doc { get; set; }

        public PrintWholeTreasureHuntInWord(string nameOfDirectoryWithPictures, string nameOfDirectoryWithTitlePages, string nameOfDirectoryWithfinalPages, string solutionWord, bool visible, string directoryToSave, bool visiblilityOfText)
        {
            VisibilityOfText = visiblilityOfText;
            DirectoryToSave = directoryToSave;
            Visibility = visible;
            WordCrossword = new CreateCrossword(solutionWord);
            NameOfDirectoryWithPictures = nameOfDirectoryWithPictures;
            NameOfDirectoryWithTitlePages = nameOfDirectoryWithTitlePages;
            AllFilesWithTitlePages = GetAllPNGFilesNames(NameOfDirectoryWithTitlePages, false);

            NameOfDirectoryWithFinalPages = nameOfDirectoryWithfinalPages;
            AllFilesWithFinalPages = GetAllPNGFilesNames(NameOfDirectoryWithFinalPages, false);

            AvailableWords = new List<string>();
            AvailableWords = GetAllPNGFilesNames(NameOfDirectoryWithPictures, true);
            PutAvailableWordsInCrossword();
            //The words used in crossword
            WordsInCrossword = WordCrossword.CreateListOfItemsInCrossword();
            //The numbers of rows in table is equal to the number of items in the crossword
            NumberOfRowsInCrosswordTable = WordsInCrossword.Count();            
            
            //Create the name of file with the result
            NameOfResultFile = DirectoryToSave + "\\"+ solutionWord + ".docx";
            Word = new Application
            {
                Visible = Visibility
            };
            Doc = new Document();
        }

        //Put the Avalilable words in Crossword
        public void PutAvailableWordsInCrossword()
        {
            foreach (string s in AvailableWords)
            {
                WordCrossword.CrosswordItems.Add(new CrosswordItem(s, s));
            }
        }

        /// <summary>
        /// Get all the names of png files that are available in the given directory
        /// if deleteLastFourChar is true, delete the last four chars in the name (if you need the words, not name of files)
        /// </summary>
        public List<string> GetAllPNGFilesNames(string nameOfTheDirectory, bool deleteLastFourChar)
        {
            DirectoryInfo directoryWithFiles = new DirectoryInfo(nameOfTheDirectory);
            List<string> allNamesOffiles = new List<string>();

            //Get the files in directory
            FileInfo[] filesNames = directoryWithFiles.GetFiles("*.png");
                        
            {
                //Add the names of the files to the list
                for (int i = 0; i < filesNames.Length; i++)
                {
                    string fileName = string.Empty;
                    if (deleteLastFourChar)
                    {
                        fileName = filesNames[i].Name.Substring(0, filesNames[i].Name.Length - 4);
                    }
                    else
                    {
                        fileName = filesNames[i].Name;
                    }
                    allNamesOffiles.Add(fileName);
                }
            }            return allNamesOffiles;
        }

        public void PutWholeTreasureHuntInWord()
        {            
            object missing = Type.Missing;
            object start = 0;
            object end = 0;
            Range firstTitleLocation = Doc.Range(ref start, ref end);
            int lastParagraph = Doc.Paragraphs.Count;
            Range location = Doc.Paragraphs[lastParagraph].Range;

            //Add all title pages
            foreach (string s in AllFilesWithTitlePages)
            {
                string nameOfTheFile = NameOfDirectoryWithTitlePages + "\\" + s;
                if (File.Exists(nameOfTheFile))
                {
                    lastParagraph = Doc.Paragraphs.Count;
                    location = Doc.Paragraphs[lastParagraph].Range;
                    location.InlineShapes.AddPicture(nameOfTheFile, ref missing, ref missing, ref missing);
                    location.InsertParagraphAfter();
                    Doc.Words.Last.InsertBreak();
                }
            }




            //Crossword          
            location.InsertAfter("Vylušti křížovku a dozvíš se, kde je poklad!");
            location.Font.Name = "Cambria";
            location.Font.Size = 15;
            location.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;

            Range tableLocation = Doc.Range(ref start, ref end);

            //tableLocation.InsertAfter(WordCrossword.ResultWord);

            object oCollapseEnd = WdCollapseDirection.wdCollapseEnd;
            tableLocation.Collapse(ref oCollapseEnd);
            tableLocation = Doc.Content;
            tableLocation.Collapse(ref oCollapseEnd);


            Table crosswordTable = Doc.Tables.Add(tableLocation, NumberOfRowsInCrosswordTable, LengthOfTableWithCrossword);
            Cell cell = Doc.Tables[1].Cell(1, 1);
            Range rangeOfTheTable = cell.Range;

            int row = 1;
            int column = 1;

            //First cycle is for the rows
            for (int i = 0; i < WordsInCrossword.Count; i++)
            {
                row = i + 1;

                //Where to start the word in the row; the offset for this word
                column = WordCrossword.FindTheHighestIndexOfResult() - WordsInCrossword[i].SolutionLetterIndex + 1;
                cell = Doc.Tables[1].Cell(row, column);
                rangeOfTheTable = cell.Range;

                //The first cell in each row is the number of the word
                rangeOfTheTable.Text = (i + 1).ToString() + ".";
                rangeOfTheTable.Font.Name = "Cambria";
                rangeOfTheTable.Font.Size = 15;
                cell.Range.Borders[WdBorderType.wdBorderRight].LineStyle = WdLineStyle.wdLineStyleSingle;
                //Second cycle is for the column (each letter in one column)
                for (int j = 0; j < WordsInCrossword[i].WordInCrossword.Length; j++)
                {
                    //go to the next column
                    column++;
                    cell = Doc.Tables[1].Cell(row, column);
                    rangeOfTheTable = cell.Range;
                    string nameOfFile = NameOfDirectoryWithPictures + "\\" + WordsInCrossword[i].WordInCrossword.ToUpper() + ".png";
                    if (VisibilityOfText || !File.Exists(nameOfFile))
                    {
                        rangeOfTheTable.Text = WordsInCrossword[i].WordInCrossword[j].ToString();
                    }
                    else
                    {
                        rangeOfTheTable.Text = " ";
                    }

                    cell.Range.Borders[WdBorderType.wdBorderRight].LineStyle = WdLineStyle.wdLineStyleSingle;
                    cell.Range.Borders[WdBorderType.wdBorderTop].LineStyle = WdLineStyle.wdLineStyleSingle;
                    cell.Range.Borders[WdBorderType.wdBorderBottom].LineStyle = WdLineStyle.wdLineStyleSingle;

                    //For the solutionword add thick borders
                    if (j == WordsInCrossword[i].SolutionLetterIndex)
                    {
                        cell.Range.Borders[WdBorderType.wdBorderLeft].LineWidth = WdLineWidth.wdLineWidth300pt;
                        cell.Range.Borders[WdBorderType.wdBorderRight].LineWidth = WdLineWidth.wdLineWidth300pt;
                        cell.Range.Borders[WdBorderType.wdBorderTop].LineWidth = WdLineWidth.wdLineWidth300pt;
                        cell.Range.Borders[WdBorderType.wdBorderBottom].LineWidth = WdLineWidth.wdLineWidth300pt;
                    }
                }
            }


            //The code to insert table after
            //Space
            oCollapseEnd = WdCollapseDirection.wdCollapseEnd;
            rangeOfTheTable.Collapse(ref oCollapseEnd);
            rangeOfTheTable = Doc.Content;
            rangeOfTheTable.Collapse(ref oCollapseEnd);
            Paragraph freeline = Doc.Paragraphs.Add(rangeOfTheTable);



            //The code to insert table after
            //pictureTable
            oCollapseEnd = WdCollapseDirection.wdCollapseEnd;
            rangeOfTheTable.Collapse(ref oCollapseEnd);
            rangeOfTheTable = Doc.Content;
            rangeOfTheTable.Collapse(ref oCollapseEnd);

            Doc.Words.Last.InsertBreak();
            Doc.Words.Last.InsertParagraphAfter();
            lastParagraph = Doc.Paragraphs.Count;
            location = Doc.Paragraphs[lastParagraph].Range;
            //Foreach word in CrossWord

            //Add number and add particular Picture
            for (int i = 0; i < WordsInCrossword.Count(); i++)
            {
                
                string nameOfTheFile = NameOfDirectoryWithPictures + "\\" + WordsInCrossword[i].WordInCrossword + ".png";
                if (File.Exists(nameOfTheFile))
                {
                    location.InsertParagraphAfter();
                    lastParagraph = Doc.Paragraphs.Count;
                    location = Doc.Paragraphs[lastParagraph].Range;
                    //Add number
                    location.Text = (i+1).ToString() + ". slovo v křížovce:";
                    //Format text
                    location.Font.Name = "Cambria";
                    location.Font.Size = 35;
                    location.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                    location.InsertParagraphAfter();
                    lastParagraph = Doc.Paragraphs.Count;
                    location = Doc.Paragraphs[lastParagraph].Range;
                    //Add picture
                    location.InlineShapes.AddPicture(nameOfTheFile, ref missing, ref missing, ref missing);
                    location.InsertParagraphAfter();
                    Doc.Words.Last.InsertBreak();
                }
            }

            //Final page(s)

            //Add all title pages
            foreach (string s in AllFilesWithFinalPages)
            {
                string nameOfTheFile = NameOfDirectoryWithFinalPages + "\\" + s;
                if (File.Exists(nameOfTheFile))
                {
                    lastParagraph = Doc.Paragraphs.Count;
                    location = Doc.Paragraphs[lastParagraph].Range;
                    location.InlineShapes.AddPicture(nameOfTheFile, ref missing, ref missing, ref missing);
                    location.InsertParagraphAfter();
                    Doc.Words.Last.InsertBreak();
                }
            }
            //delete last 2 paragraphs
            lastParagraph = Doc.Paragraphs.Count;
            location = Doc.Paragraphs[lastParagraph].Range;
            location.Delete();

            lastParagraph = Doc.Paragraphs.Count;
            location = Doc.Paragraphs[lastParagraph].Range;
            location.Delete();

            //save doc
            Doc.SaveAs2(NameOfResultFile);
            Doc.Close();

            ///Close the word app

            Word.Quit();
        }
    }
}
