﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;

namespace PictureCrossword
{
    class Program
    {
        static void Main(string[] args)
        {
            string flowers = "C:\\Users\\kolaf\\OneDrive\\Documents\\blog\\Blog2021\\Křížovky do bojovek\\Flowers";
            string animals = "C:\\Users\\kolaf\\OneDrive\\Documents\\blog\\Blog2021\\Křížovky do bojovek\\Animals";
            string places = "C:\\Users\\kolaf\\OneDrive\\Documents\\blog\\Blog2021\\Křížovky do bojovek\\Místa v Česku";
            string animalEn = "C:\\Users\\kolaf\\OneDrive\\Documents\\blog\\Blog2021\\Křížovky do bojovek\\AnimalsAj";
            //"David", "Erinka", "Adam", "Nikola", "Vitek", "Martin", "Jindra", "Emilka", "Tomáš", "Rozcestí", "Strom", "Branka", "Kompost"
            //string whereToSave = "C:\\Users\\kolaf\\OneDrive\\Documents\\blog\\Blog2021\\Křížovky do bojovek\\KrizovkyZProgramu\\";
            string whereToSave = "C:\\Users\\kolaf\\OneDrive\\Documents\\Dokumenty2021\\2021-celotaborova-hra-zvirata\\Křížovky se jmény\\";

            //Pirates tresure hunt
            string piratsTasks = "C:\\Users\\kolaf\\OneDrive\\Documents\\blog\\Blog2021\\Bojovka piráti\\Úkoly";
            string piratsTitle = "C:\\Users\\kolaf\\OneDrive\\Documents\\blog\\Blog2021\\Bojovka piráti\\Titulní";
            string piratsEnd = "C:\\Users\\kolaf\\OneDrive\\Documents\\blog\\Blog2021\\Bojovka piráti\\Konec";
            string piratsWhereToSave = "C:\\Users\\kolaf\\OneDrive\\Documents\\blog\\Blog2021\\Bojovka piráti\\Bojovky";

            string tajenka = "Pod lavičkou";

            //Všechny pirátské bojovky naráz
            List<string> treasurePlaces = new List<string>() { "Pod lavičkou", "Ve stáji", "Ve foliovníku", "Záhonek rajčata", "Stará kůlna", "U hrobky", "Křivá borovice"};

            foreach (string s in treasurePlaces)
            {

                PrintWholeTreasureHuntInWord printPirateTreasureHunt = new PrintWholeTreasureHuntInWord(piratsTasks, piratsTitle, piratsEnd, s, false, piratsWhereToSave, false);
                printPirateTreasureHunt.PutWholeTreasureHuntInWord();
            }

            //List<string> names = new List<string>(){ "Tomas"};

            //Sources sources = new Sources();
            //sources.AddCzechNames();
            //List<string> names = sources.ResultWordsInCrossword;


            //List<string> names = new List<string>() {"Ahoj", "Kočka"};

            //foreach (string s in names)
            //{
            //    PrintInWord printInWord = new PrintInWord(animalEn, s, false, whereToSave);
            //    printInWord.PrintCrosswordInTable();
            //   // foreach (string a in printInWord.AvailableWords)
            //   //{
            //   //     Console.WriteLine(a);
            //   // }
            //}

            //PrintInWord printInWord = new PrintInWord(flowers, "hovno");
            //printInWord.PrintCrosswordInTable();

            //PrintInWord printInWord = new PrintInWord(flowers, "Za tabulí");
            //printInWord.PrintCrosswordInTable();

            //PrintInWord printInWord2 = new PrintInWord(flowers, "V třídnici");
            //printInWord2.PrintCrosswordInTable();

            //PrintInWord printInWord3 = new PrintInWord(flowers, "Na nástěnce");
            //printInWord3.PrintCrosswordInTable();

            //PrintInWord printInWord4 = new PrintInWord(flowers, "Pod katedrou");
            //printInWord4.PrintCrosswordInTable();

            //PrintInWord printInWord5 = new PrintInWord(flowers, "V umyvadle");
            //printInWord5.PrintCrosswordInTable();

            //PrintInWord printInWord6 = new PrintInWord(flowers, "Pode dveřmi");
            //printInWord6.PrintCrosswordInTable();

            //test prirazovani nazvu souboru
            //foreach (string s in printInWord.AvailableWords)
            //{
            //    Console.WriteLine(s);
            //}

            //printInWord.PrintAllInWord();

            Console.ReadKey();
        }
    }
}
