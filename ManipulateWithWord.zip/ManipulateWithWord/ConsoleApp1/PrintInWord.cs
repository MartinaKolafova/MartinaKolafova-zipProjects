﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;
using System.IO;

namespace PictureCrossword
{
    /// <summary>
    /// Print one crossword with pictures in word
    /// </summary>
    public class PrintInWord
    {
        /// <summary>
        /// The words in crossword
        /// </summary>
        public List<string> AvailableWords { get; set; }

        public List<CrosswordItem> WordsInCrossword { get; set; }

        public string NameOfDirectoryWithPictures { get; set; }

        public CreateCrossword WordCrossword { get; set; }

        /// <summary>
        /// he length of table  with the crossword 
        /// </summary>
        public int lengthOfTableWithCrossword;

        /// <summary>
        /// Is the Word App visible?
        /// </summary>
        public bool Visibility { get; set; }

        /// <summary>
        /// Where to save the files with crosswords
        /// </summary>
        public string DirectoryToSave { get; set; }

        /// <summary>
        /// the name of reult file
        /// </summary>
        private string NameOfResultFile { get; set; }


        /// <summary>
        /// The length of table  with the crossword
        /// First column = numbers
        /// Crossword starts from second column
        /// </summary>
        public int LengthOfTableWithCrossword
        {
            get
            {
                //The maximum lengthe of a word after soultion index
                int maxAfterSolutionIndex = WordsInCrossword.Max(x => x.WordInCrossword.Length - (x.SolutionLetterIndex + 1));
                //the maximum solution letter index + 1 
                int maxLettersBeforeSolutionIndex = WordsInCrossword.Max(x => x.SolutionLetterIndex) + 1;
                //The maximum length of the table is the maximum number of letter before the solution letter index + the maximme after solution letterindex + 1 
                lengthOfTableWithCrossword = maxAfterSolutionIndex + maxLettersBeforeSolutionIndex + 1;
                return lengthOfTableWithCrossword;
            }
            set
            {
                lengthOfTableWithCrossword = value;
            }

        }

        public int NumberOfRowsInCrosswordTable { get; set; }
        

        Document Doc { get; set; }        

        public PrintInWord(string nameOfDirectoryWithPictures, string solutionWord, bool visible, string directoryToSave)
        {
            DirectoryToSave = directoryToSave;
            
            Visibility = visible;
            WordCrossword = new CreateCrossword(solutionWord);
            NameOfDirectoryWithPictures = nameOfDirectoryWithPictures;
            AvailableWords = new List<string>();
            GetAvailableWords();
            PutAvailableWordsInCrossword();
            //The words used in crossword
            WordsInCrossword = WordCrossword.CreateListOfItemsInCrossword();

            //The numbers of rows in table is equal to the number of items in the crossword
            NumberOfRowsInCrosswordTable = WordsInCrossword.Count();
            // Document Doc = new Document();
            //object missing = Type.Missing;

            //Create the name of file
            NameOfResultFile = DirectoryToSave + solutionWord + ".docx";
        }

        //Put the Avalilable words in Crossword
        public void PutAvailableWordsInCrossword()
        {
            foreach (string s in AvailableWords)
           {
                WordCrossword.CrosswordItems.Add(new CrosswordItem(s, s));
            }
        }

        /// <summary>
        /// Get the words that are available for the crossword from the names of files in given directory
        /// </summary>
        public void GetAvailableWords()
        {
            DirectoryInfo directoryWithPictures = new DirectoryInfo(NameOfDirectoryWithPictures); 

            //Get the files in directory
            FileInfo[] filesNames = directoryWithPictures.GetFiles("*.jpg");

            //Add the names of the files to the crossword
            for (int i = 0; i < filesNames.Length; i++)
            {
                string fileName = filesNames[i].Name.Substring(0, filesNames[i].Name.Length-4);
                AvailableWords.Add(fileName);
            }
        }

        public void PrintCrosswordInTable()
        {
            Application Word = new Application
            {
                Visible = Visibility
            };
            Document Doc = new Document();
            object missing = Type.Missing;
            object start = 0;
            object end = 0;
            Range tableLocation = Doc.Range(ref start, ref end);

            tableLocation.InsertAfter(WordCrossword.ResultWord);

            object oCollapseEnd = WdCollapseDirection.wdCollapseEnd;
            tableLocation.Collapse(ref oCollapseEnd);
            tableLocation = Doc.Content;
            tableLocation.Collapse(ref oCollapseEnd);


            Table crosswordTable = Doc.Tables.Add(tableLocation, NumberOfRowsInCrosswordTable, LengthOfTableWithCrossword);
            Cell cell = Doc.Tables[1].Cell(1, 1);
            Range rangeOfTheTable = cell.Range;

            int row = 1;
            int column = 1;

            //First cycle is for the rows
            for (int i = 0; i < WordsInCrossword.Count; i++)
            {
                row = i + 1;
                 
                //Where to start the word in the row; the offset for this word
                column = WordCrossword.FindTheHighestIndexOfResult() - WordsInCrossword[i].SolutionLetterIndex + 1;
                cell = Doc.Tables[1].Cell(row, column);
                rangeOfTheTable = cell.Range;

                //The first cell in each row is the number of the word
                rangeOfTheTable.Text = (i + 1).ToString() + ".";
                cell.Range.Borders[WdBorderType.wdBorderRight].LineStyle = WdLineStyle.wdLineStyleSingle;
                //Second cycle is for the column (each letter in one column)
                for (int j = 0; j < WordsInCrossword[i].WordInCrossword.Length; j++)
                {
                    //go to the next column
                    column++;
                    cell = Doc.Tables[1].Cell(row, column);
                    rangeOfTheTable = cell.Range;
                    rangeOfTheTable.Text = WordsInCrossword[i].WordInCrossword[j].ToString();

                    cell.Range.Borders[WdBorderType.wdBorderRight].LineStyle = WdLineStyle.wdLineStyleSingle;
                    cell.Range.Borders[WdBorderType.wdBorderTop].LineStyle = WdLineStyle.wdLineStyleSingle;
                    cell.Range.Borders[WdBorderType.wdBorderBottom].LineStyle = WdLineStyle.wdLineStyleSingle;

                    //For the solutionword add thick borders
                    if (j == WordsInCrossword[i].SolutionLetterIndex)
                    {
                        cell.Range.Borders[WdBorderType.wdBorderLeft].LineWidth = WdLineWidth.wdLineWidth300pt;
                        cell.Range.Borders[WdBorderType.wdBorderRight].LineWidth = WdLineWidth.wdLineWidth300pt;
                        cell.Range.Borders[WdBorderType.wdBorderTop].LineWidth = WdLineWidth.wdLineWidth300pt;
                        cell.Range.Borders[WdBorderType.wdBorderBottom].LineWidth = WdLineWidth.wdLineWidth300pt;
                    } 
                }                
            }

            
            //The code to insert table after
            //Space
            oCollapseEnd = WdCollapseDirection.wdCollapseEnd;
            rangeOfTheTable.Collapse(ref oCollapseEnd);
            rangeOfTheTable = Doc.Content;
            rangeOfTheTable.Collapse(ref oCollapseEnd);
            Paragraph freeline = Doc.Paragraphs.Add(rangeOfTheTable);

            //The code to insert table after
            //pictureTable
            oCollapseEnd = WdCollapseDirection.wdCollapseEnd;
            rangeOfTheTable.Collapse(ref oCollapseEnd);
            rangeOfTheTable = Doc.Content;
            rangeOfTheTable.Collapse(ref oCollapseEnd);

            //Create Table for the pictures
            int numberOfColums = 3;
            int modulo = WordsInCrossword.Count() / 3;
            int numberOfRows;

            if (modulo == 0)
            {
                numberOfRows = (WordsInCrossword.Count() / 3) * 2;
            }
            else
            {
                numberOfRows = (WordsInCrossword.Count() / 3 + 1) * 2;
            }

            Table pictureTable = Doc.Tables.Add(rangeOfTheTable, numberOfRows, numberOfColums);
            cell = pictureTable.Cell(1, 1);
            Range rangeOfThePictureTable = pictureTable.Range;
            //for (int j = 0; j < 3; j++)
            //{
            int cellColumn = 1;
            int cellRow = 1;
            for (int i = 1; i <= WordsInCrossword.Count(); i++)
            {
                cell = pictureTable.Cell(cellRow, cellColumn);
                rangeOfThePictureTable = cell.Range;
                //rangeOfTheTable.Text = WordsInCrossword[i-1];
                AddPicture(WordsInCrossword[i - 1].WordInCrossword, rangeOfThePictureTable);
                cell = pictureTable.Cell(cellRow + 1, cellColumn);
                rangeOfThePictureTable = cell.Range;
                rangeOfThePictureTable.Text = (i).ToString() + ".";

                cellRow = ((i / 3) * 2 + 1);
                cellColumn = 1;
                if (i % 3 == 1)
                {
                    cellColumn = 2;
                }
                if (i % 3 == 2)
                {
                    cellColumn = 3;
                }

                //cell = pictureTable.Cell(cellRow, cellColumn);
                //rangeOfThePictureTable = cell.Range;
            }
            Doc.SaveAs2(NameOfResultFile);
            Doc.Close();

            ///Close the word app

            Word.Quit();
        }

       

        public void AddPicture(string fileName, Range range)
        {
            object missing = Type.Missing;
            string nameOfTheFile = NameOfDirectoryWithPictures + "\\" + fileName + ".jpg";
            if (File.Exists(nameOfTheFile))
            {
                range.InlineShapes.AddPicture(nameOfTheFile, ref missing, ref missing, ref missing);
            }
            else
            {
                range.Text = " ";
            }
        }

    }
}


