﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PictureCrossword
{
    public class Sources
    {
        /// <summary>
        /// The set of result words in crossword
        /// </summary>
        public List<string> ResultWordsInCrossword { get; set; }


        //The file where the pictureas are saved
        public string FileOfPictures { get; set; }


        public Sources()
        {
            ResultWordsInCrossword = new List<string>();            
        }

        /// <summary>
        /// Add all CZ names to the list of result words
        /// </summary>
        public void AddCzechNames()
        {

            List<string> names = new List<string>() { "Michael", "Michal", "Mikuláš", "Milan", "Miroslav", "Nicolas", "Nikolas", "Oldřich", "Oliver", "Ondřej", "Oskar", "Patrik", "Pavel", "Petr", "Prokop", "Radek", "Radim", "René", "Richard", "Robert", "Robin", "Roman", "Rostislav", "Rudolf", "Samuel", "Sebastian", "Sebastián", "Stanislav", "Šimon", "Štěpán", "Tadeáš", "Teodor", "Theodor", "Tobias", "Tobiáš", "Tomáš", "Václav", "Viktor", "Vilém", "Vincent", "Vít", "Vítek", "Vladimír", "Vojta", "Vojtěch", "Zdeněk" };
            //"Adéla", "Adriana", "Agáta", "Alena", "Alexandra", "Alice", "Alžběta", "Amálie", "Amélie", "Andrea", "Aneta", "Anežka", "Anna", "Bára", "Barbora", "Beáta", "Daniela", "Denisa", "Diana", "Dominika", "Dorota", "Ela", "Elen", "Elena", "Eliška", "Ella", "Ellen", "Ema", "Emma", "Ester", "Eva", "Gabriela", "Hana", "Helena", "Izabela", "Jana", "Johana", "Jolana", "Josefína", "Julie", "Justýna", "Kamila", "Karolína", "Kateřina", "Klára", "Klaudie", "Kristina", "Kristýna", "Laura", "Lea", "Lenka", "Leona", "Leontýna", "Liliana", "Linda", "Lucie", "Magdalena", "Magdaléna", "Mariana", "Marie", "Markéta", "Martina", "Mia", "Michaela", "Monika", "Natálie", "Nela", "Nella", "Nelly", "Nicol", "Nikol", "Nikola", "Nina", "Patricie", "Pavla", "Pavlína", "Petra", "Rozálie", "Sabina", "Sandra", "Sára", "Simona", "Sofie", "Soňa", "Stela", "Stella", "Šárka", "Šarlota", "Štěpánka", "Tereza", "Terezie", "Valentýna", "Valerie", "Valérie", "Vanesa", "Vanessa", "Vendula", "Veronika", "Viktorie", "Zuzana", "Adam", "Adrian", "Albert", "Aleš", "Alex", "Alexander", "Alexandr", "Andrej", "Antonín", "Benjamin", "Dalibor", "Damián", "Dan", "Daniel", "David", "Denis", "Dominik", "Eduard", "Eliáš", "Erik", "Filip", "František", "Gabriel", "Hugo", "Hynek", "Ivan", "Jáchym", "Jakub", "Jan", "Jaromír", "Jaroslav", "Jindřich", "Jiří", "Jonáš", "Josef", "Kamil", "Karel", "Kevin", "Kristian", "Kristián", "Kryštof", "Ladislav", "Libor", "Luboš", "Lukáš", "Marek", "Martin", "Matěj", "Matouš", "Matyas", "Matyáš", "Max", "Maxim", "Maxmilián"
            ResultWordsInCrossword = names;
        }

    }
}
