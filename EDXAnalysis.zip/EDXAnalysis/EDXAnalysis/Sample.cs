﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDXAnalysis
{
    /// <summary>
    /// Each sample consist of 1-20 elements
    /// </summary>
    class Sample
    {
        public List<Element> Elements { get; set; }

        /// <summary>
        /// name of the sample
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Date of sample preparation
        /// </summary>
        public string DateOfSamplePreparation { get; set; }

        /// <summary>
        /// Date of measurement of the sample
        /// </summary>
        public string DateOfMeasurement { get; set; }

        /// <summary>
        /// Surface of the sample can be A, B C or D 
        /// TO DO - control?
        /// </summary>
        public string Surface { get; set; }

        /// <summary>
        /// A point of the sample, where analysis was done
        /// Can be A, B, C or unknown 
        /// TO DO -> vycet? Jiny typ?
        /// </summary>
        public string PointOfAnalysis { get; set; }

        public string Diameter { get; set; }

        public string Kcps { get; set; }

        /// <summary>
        /// Worker is the person, who performed the analysis.
        /// 
        /// </summary>
        public string Worker { get; set; }

        /// <summary>
        /// Description of the sample
        /// Only inicials are used to describe the person
        /// MK = Martina Kolafova
        /// PP = Petr Plat
        /// AF = Alzbeta Flidrova
        /// JS = Jan Stovicek
        /// </summary>
        public string Description { get; set; }

        public string Description2 { get; set; }

        public Sample(string name, string surface, string dateOfSamplePreparation, string dateOfMeasurement, string pointOfAnalysis, string diameter, string kcps, string worker, string description, string description2)
        {
            Elements = new List<Element>() { };
            Name = name;
            Surface = surface;
            DateOfSamplePreparation = dateOfSamplePreparation;
            DateOfMeasurement = dateOfMeasurement;
            Diameter = diameter;
            Kcps = kcps;
            Description = description;
            PointOfAnalysis = pointOfAnalysis;
            Worker = worker;
            Description2 = description2;
        }

        //return string with Sample's properties in the required order to be written in database
        public override string ToString()
        {
            string sampleToString = Name + " " + Surface + " " + DateOfSamplePreparation.Substring(0, 2) + " " + DateOfSamplePreparation.Substring(3, 2) + " " + DateOfSamplePreparation.Substring(6, 2) +
                        " " + DateOfMeasurement.Substring(0, 2) + " " + DateOfMeasurement.Substring(3, 2) + " " + DateOfMeasurement.Substring(6, 2) + " " + PointOfAnalysis + " " + Diameter + " " + Kcps + " " + Worker + " " +  Description + " " + Description2 + " " +
                        ControlW().ToString() + " " + ControlA().ToString();

                return sampleToString;
        }

        // ToString() method of selected element
        public string SelectedElementToString (string elementName)
        {
            foreach (Element element in Elements)
            {
                if (element.Name == elementName)
                {
                    return element.ToString();
                }
            }

            return " 0 0 0 0";
        }

        //W % should be between 99.9 % and 100.1%
        public double ControlW ()
        {
            double controlW = 0;
            foreach(Element element in Elements)
            {
                controlW += element.WeightPercentage;
            }

            return controlW;
        }

        //At % should be between 99.9 % and 100.1%
        public double ControlA()
        {
            double controlA = 0;
            foreach (Element element in Elements)
            {
                controlA += element.AtomicPercentage;
            }

            return controlA;
        }
    }
}
