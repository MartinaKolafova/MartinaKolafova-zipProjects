﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDXAnalysis
{
    /// <summary>
    /// Set of analysis to work with...
    /// </summary>
    class SetOfAnalysis
    {
        public List<Sample> SetOfAnalysisForFurtherWork { get; set; }

        public string NameOfTheSetOfAnalysis { get; set; }

        public SetOfAnalysis (List<Sample> setOfAnalysisToWorkWith, string name)
        {
            SetOfAnalysisForFurtherWork = setOfAnalysisToWorkWith;
            NameOfTheSetOfAnalysis = name;
        }        
    }
}
