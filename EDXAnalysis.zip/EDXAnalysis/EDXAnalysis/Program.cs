﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;
using Microsoft.Office.Interop.Excel;



namespace EDXAnalysis
{
    class Program
    {
        static void Main(string[] args)
        {
            //Read txt.file and add  
            string line;
            List<string> lines = new List<string>();
            //
            List<Sample> samplesProcessed = new List<Sample>();


            //Directory.GetFiles();
            string[] files = Directory.GetFiles("../Program-ke-zpracovani-souboru-Analyzy/Soubory-ke-zpracovani", "*.txt"); //Relative path??? "C:/Users/kolaf/OneDrive/Desktop/Kaktus/EDX-analysis/EDXAnalysis/EDXAnalysis/bin/Debug"
            SetOfAnalysis setOfAnalysis = new SetOfAnalysis(samplesProcessed, "Test");

            foreach (string file in files)
            {
                //Read lines from file
                using (StreamReader reader = new StreamReader(file))
                {
                    //TO DO Sample name from the name of file
                    //TO DO Date of sample preparation - format

                    if (!file.Contains("Database")) //Take all files exept the one, where the result of this program should be store / to do - improve control of files names parameters
                    {
                        while ((line = reader.ReadLine()) != null)
                        {
                            lines.Add(line);
                        }
                    }
                }

                if (!file.Contains("Database"))
                {
                    List<string> fileNameSeparated = file.Split('x', '\\').Where(p => (p != "x" && !string.IsNullOrWhiteSpace(p))).ToList();
                    string nameOfSample = fileNameSeparated[1].Substring(0, fileNameSeparated[1].Length - 2);

                    string surface = fileNameSeparated[1].Substring(fileNameSeparated[1].Length - 1, 1); //Surface can have only one char
                    string dateOfEtching = fileNameSeparated[2]; //YY-MM-DD
                    string dateOfMeasurement = fileNameSeparated[6].Substring(0, 8); //YY-MM-DD
                    string pointOfAnalysis = fileNameSeparated[3]; //A, B, C or NA

                    string diameter;
                    //There can be NA in the name, if the parameter is unavailable
                    if (fileNameSeparated[4] != "NA")
                    {
                        diameter = fileNameSeparated[4].Substring(0, 3).Replace('-', ',');
                    }
                    else
                    {
                        diameter = "NA";
                    }

                    string kcps;
                    if (!fileNameSeparated[5].Contains("NA"))
                    {
                        kcps = fileNameSeparated[5].Substring(0, 3).Replace('-', ',');
                    }
                    else
                    {
                        kcps = "NA";
                    }

                    string worker = "NA";
                    if (fileNameSeparated.Count() > 7)
                    {
                        worker = fileNameSeparated[7].Substring(0, 2);
                    }

                    string description2 = fileNameSeparated[fileNameSeparated.Count - 2].Substring(0, fileNameSeparated[fileNameSeparated.Count - 2].Length - 2);

                    Sample sampleFromThisFile = new Sample(nameOfSample, surface, dateOfEtching, dateOfMeasurement, pointOfAnalysis, diameter, kcps, worker, "PCadded", description2); //doplnit kcps, dateOfEtching etc.

                    for (int i = 0; i < lines.Count(); i++)
                    {
                        if (lines[i].Contains("---"))
                        {
                            for (int j = i + 1; j < lines.Count() - 1; j++)
                            {
                                string controlString = lines[j + 1];
                                if (!lines[j + 1].Contains("Total:") && !lines[j].Contains("---"))
                                {
                                    //Find white spaces and their index in the string
                                    //string [] dataFromLinesSeparated = lines[j].Split(' '); //TO DO Should be all whitespaces

                                    List<string> dataFromLinesSeparated = lines[j].Split(' ').Where(p => !string.IsNullOrWhiteSpace(p)).ToList(); //TO DO - remove whitespaces, change the numbers
                                    string name = dataFromLinesSeparated[0];
                                    Double.TryParse(dataFromLinesSeparated[3], NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out double weightPercentageUnn);
                                    Double.TryParse(dataFromLinesSeparated[4], NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out double weightPercentage);
                                    Double.TryParse(dataFromLinesSeparated[5], NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out double atomicPercentage);
                                    Double.TryParse(dataFromLinesSeparated[6], NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out double errorOfElement);

                                    sampleFromThisFile.Elements.Add(new Element(name, weightPercentageUnn, weightPercentage, Convert.ToDouble(atomicPercentage), Convert.ToDouble(errorOfElement)));
                                }
                            }
                        }
                    }
                    samplesProcessed.Add(sampleFromThisFile);
                    lines.Clear();
                }
            }

            //make a line from sample from this file
            //add the line to the result table
            //delete all from sample
            //new file

            string dateOfCreation = DateTime.Now.ToString() + "newDatabase.txt";
                        
            using (StreamWriter newDatabase = new StreamWriter("novaDatabaze"))

            {
                foreach (Sample sample in samplesProcessed)
                {
                    string newLineInDatabase;

                    newLineInDatabase = sample.ToString()
                      + sample.SelectedElementToString("C")
                      + sample.SelectedElementToString("O")
                      + sample.SelectedElementToString("Na")
                      + sample.SelectedElementToString("Ti")
                      + sample.SelectedElementToString("Cl")
                      + sample.SelectedElementToString("Ca")
                      + sample.SelectedElementToString("Si")
                      + sample.SelectedElementToString("N")
                      + sample.SelectedElementToString("Al");
                   
                    newDatabase.WriteLine(newLineInDatabase);
                }
            }

            //Put the date in Excel
            Application excel = new Application
            {
                Visible = true
            };

            using (StreamReader newDatabaseReader = new StreamReader("novaDatabaze"))
            {                
                _Workbook xlWorkbook = excel.Workbooks.Add(); 
                Range cell = excel.ActiveCell;
                
                //Title line
                string[] cellNames = new string[] { "Sample", "Surface", "Date of Etching - Year", "Date of Etching - Month", 
                    "Date of Etching - Day", "Date of Measurement - Year", "Date of Measurement - Month", "Date of Measurement - Day", 
                    "Measured Point", "Diameter", "kcps", "Operator", "Description", "Description 2", "Control 1", "Control 2", "C unn. wt%", "C norm wt %", "C at %", "C Error[%]", "O unn. wt%", "O norm wt %", "O at %", "O Error[%]", "Na unn. wt%", "Na norm wt %", "Na at %", "Na Error[%]", "Ti unn. wt%", "Ti norm wt %", "Ti at %", "Ti Error[%]", "Cl unn. wt%", "Cl norm wt %", "Cl at %", "Cl Error[%]", "Ca unn. wt%", "Ca norm wt %", "Ca at %", "Ca Error[%]", "Si unn. wt%", "Si norm wt %", "Si at %", "Si Error[%]", "N unn. wt%", "N norm wt %", "N at %", "N Error[%]", "Al unn. wt%", "Al norm wt %", "Al at %", "Al Error[%]" };
                
                //Put the title in the first cells
                foreach (string s in cellNames)
                {
                    cell.Value = s;
                    cell = cell.Next;
                }

                //Go to the first cell under the title line
                cell = cell.Offset[1, -cellNames.Length];

                string lineInDatabase; //line in the database
                
                //Read the *.txt database file that was created and put the data in Excel 
                List<string> lineInDatabaseSeparated = new List<string>();

                while ((lineInDatabase = newDatabaseReader.ReadLine()) != null)
                {
                    lineInDatabaseSeparated = lineInDatabase.Split(' ').ToList(); 
                    foreach (string s in lineInDatabaseSeparated)
                    {
                        cell.Value = s;
                        cell = cell.Next;
                    }
                    cell = cell.Offset[1, -lineInDatabaseSeparated.Count()];
                    lineInDatabaseSeparated.Clear();
                }
            }

            Console.ReadKey(); 
        }
    }
}
