﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDXAnalysis
{
    /// <summary>
    /// Each element has a name and its results in at%, w% and error of the result in %
    /// </summary>
    class Element
    {
        /// <summary>
        /// Name of the element
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Weight percentage of the element unnormalized
        /// </summary>
        public double WeightPercentageUnn { get; set; }

        /// <summary>
        /// Weight percentage of the element, normalized
        /// </summary>
        public double WeightPercentage { get; set; }

        /// <summary>
        /// Atomic percentage of the element, normalized
        /// </summary>
        public double AtomicPercentage { get; set; }

        /// <summary>
        /// Error of the element's results
        /// </summary>
        public double ErrorOfElement { get; set; }
        
        public Element(string name, double weightPercentageUnn, double weightPercentage, double atomicPercentage, double errorOfElement)
        {
            Name = name;
            //weightPercentage, atomicPercentage and errorOfElement must be between 0 and 100
            if (weightPercentage < 0 || (atomicPercentage < 0) || (errorOfElement < 0) || (weightPercentage > 100) || atomicPercentage > 100 || errorOfElement > 100)
            {
                throw new ArgumentOutOfRangeException("Weight percentage, atomic percentage and error of element must be between 0 and 100");
            }
            
            WeightPercentage = weightPercentage;
            AtomicPercentage = atomicPercentage;
            ErrorOfElement = errorOfElement;
            WeightPercentageUnn = weightPercentageUnn;
        }

        //return string with elements properties in the required order to be written in database
        public override string ToString()
        {
            string elementToSTring = " " + WeightPercentageUnn.ToString() + " " + WeightPercentage.ToString() + " " + AtomicPercentage.ToString() + " "
                            + ErrorOfElement.ToString();
            return elementToSTring;
        }

       


    }
}
