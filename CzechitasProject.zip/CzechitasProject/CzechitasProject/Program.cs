﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CzechitasProject
{
    class Program
    {       

        static void Main(string[] args)
        {           
            Game<IQuestion> game = new Game<IQuestion>();
            game.PlayTheMathGame();
            Console.ReadKey();              
        }
    }
}
