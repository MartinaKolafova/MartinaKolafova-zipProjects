﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CzechitasProject
{
    /// <summary>
    /// The ABC question, answer can be only A, B or C 
    /// </summary>
    class ABCQuestion : IQuestion
    {
        public WasTheQuestionAnswered WasThisQuestionAnswered { get; set; }
        public WasTheQuestionAnsweredCorrectly WasTheQuestionAnsweredCorrectly { get; set; }
        public int LevelOfTheQuestion { get; set; }
        public string TheQuestion { get; set; }
        public string TheAnswer { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
