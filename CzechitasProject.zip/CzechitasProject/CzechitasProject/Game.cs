﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CzechitasProject
{
    public class Game<T> where T:IQuestion
    {
        /// <summary>
        /// List of questions in this game
        /// </summary>
        public List<IQuestion> QuestionsInThisGame { get; set; }

        /// <summary>
        /// Level of this game. Starts with 1
        /// Default number is 1 
        /// </summary>
        private int levelOfThisGame = 1;

        /// <summary>
        /// Level of this game
        /// Starts with 1. If lower number is given, level is set to 1.
        /// </summary>
        public int LevelOfThisGame 
        {
            get
            {
                if (levelOfThisGame < 1)
                {
                    return 1;
                }
                else
                {
                    return levelOfThisGame;
                }
            } 
            set
            {
                levelOfThisGame = value;
            }
        } 

        /// <summary>
        /// Constructor when questions are given
        /// </summary>
        /// <param name="questionsInThisGame">List of questions</param>
        public Game (List<IQuestion> questionsInThisGame)
        {
            QuestionsInThisGame = questionsInThisGame;
            LevelOfThisGame = questionsInThisGame.Min<IQuestion>(x => x.LevelOfTheQuestion); //Level of the game should statr with the lower level in the game
        }

        /// <summary>
        /// Constructor 
        /// </summary>
        public Game()
        {
            QuestionsInThisGame = new List<IQuestion>();
            LevelOfThisGame = levelOfThisGame;
        }

        /// <summary>
        /// 
        /// </summary>
        public void PlayTheMathGame()
        {
            PlayOneLevelOfMathGame(3);

        }

        public void PlayOneLevelOfMathGame(int numberOfQuestionInOneLevel)
        {
            int entryLevel = LevelOfThisGame;
            int countCorrectAnswer = 0;
            while (LevelOfThisGame == entryLevel)
            {
                MathQuestionInt newQuestion = new MathQuestionInt();
                QuestionsInThisGame.Add(newQuestion);
                Console.WriteLine($"Spočítej, kolik je {QuestionsInThisGame.Last().TheQuestion}");
                Console.Write("Odpověď je: ");
                string answerOfThisQuestion = Console.ReadLine();
                if (answerOfThisQuestion == QuestionsInThisGame.Last().TheAnswer)
                {
                    //QuestionsInThisGame.Last().WasThisQuestionAnswered = WasTheQuestionAnswered.WasAnswered;
                    QuestionsInThisGame.Last().WasTheQuestionAnsweredCorrectly = WasTheQuestionAnsweredCorrectly.WasOK;
                    countCorrectAnswer++;
                    PrintPhrase.PrintWasOK();
                    PrintPhrase.PrintNumberOfCorrectQuestionInThisLevel(CountNumberOfCorrectAnswerOfThisLevel());
                }
                else
                {
                    //QuestionsInThisGame.Last().WasThisQuestionAnswered = WasTheQuestionAnswered.WasAnswered;
                    QuestionsInThisGame.Last().WasTheQuestionAnsweredCorrectly = WasTheQuestionAnsweredCorrectly.WasNotOK;
                }
                if (countCorrectAnswer == numberOfQuestionInOneLevel) //zmen na 10
                {
                    PrintHappyMan myHappyMan = new PrintHappyMan();
                    myHappyMan.HappyManAnimationInTheGame(30, 10);
                    LevelOfThisGame++;
                }
            }
        }

        /// <summary>
        /// Count number of correct answer in this level
        /// </summary>
        /// <returns>Number of correct answer in this level</returns>
        public int CountNumberOfCorrectAnswerOfThisLevel()
        {
            return QuestionsInThisGame.Where<IQuestion>(x => x.LevelOfTheQuestion == LevelOfThisGame && x.WasTheQuestionAnsweredCorrectly == WasTheQuestionAnsweredCorrectly.WasOK).Count();
        }

        public void ResetAnswersInGame()
        {
            foreach (IQuestion item in QuestionsInThisGame)
            {
                item.WasTheQuestionAnsweredCorrectly = WasTheQuestionAnsweredCorrectly.WasNotAnswered;
            }
        }        
    }
}
