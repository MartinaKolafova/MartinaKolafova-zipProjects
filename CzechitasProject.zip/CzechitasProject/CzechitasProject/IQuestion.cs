﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace CzechitasProject
{
    public enum WasTheQuestionAnswered { WasNotAnswered, WasAnswered}

    public enum WasTheQuestionAnsweredCorrectly { WasNotAnswered, WasOK, WasNotOK}

    public interface IQuestion : INotifyPropertyChanged
    {
        WasTheQuestionAnswered WasThisQuestionAnswered { get; set; }

        WasTheQuestionAnsweredCorrectly WasTheQuestionAnsweredCorrectly { get; set; }

        int LevelOfTheQuestion { get; set; }

        string TheQuestion { get; set; }

        string TheAnswer { get; set; }
    }
}
