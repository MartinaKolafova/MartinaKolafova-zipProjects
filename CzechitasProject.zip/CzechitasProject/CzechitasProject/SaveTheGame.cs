﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CzechitasProject
{
    static class SaveTheGame
    {
        //TO DO - save the game as .txt (?) file
    }
}
