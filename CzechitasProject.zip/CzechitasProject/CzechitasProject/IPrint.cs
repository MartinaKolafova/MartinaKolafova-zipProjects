﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CzechitasProject
{
    public interface IPrint
    {
        /// <summary>
        /// Method to delete everything in the console
        /// </summary>
        void DeleteScreen();

        /// <summary>
        /// Print what you want to print
        /// </summary>
        /// <param name="startLeft">Where you want to print it - cursore position left</param>
        /// <param name="startTop">Where you want to print it - cursore position top</param>
        void Print(int startLeft, int startTop);
        
    }
}
