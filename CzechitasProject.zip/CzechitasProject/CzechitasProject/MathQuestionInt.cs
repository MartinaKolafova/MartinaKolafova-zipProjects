﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace CzechitasProject
{  
    /// <summary>
    /// Operator to be used
    /// </summary>
    enum Operators
    {
        Plus,
        Minus,
        Times,
        Divided
    }

    /// <summary>
    /// Class of the math question; numbers as integar only
    /// </summary>
    public class MathQuestionInt : IQuestion //INotifyPropertyChanged - TO BE DONE
    {
        public event PropertyChangedEventHandler PropertyChanged; //TO BE IMPLEMENTED

        /// <summary>
        /// Was the question allready answered?
        /// </summary>
        private WasTheQuestionAnswered wasTheQuestionAnswered = WasTheQuestionAnswered.WasNotAnswered;
        public WasTheQuestionAnswered WasThisQuestionAnswered { 
            get => wasTheQuestionAnswered; 
            set
            {
                wasTheQuestionAnswered = value;
                OnPropertyChanged(nameof(WasTheQuestionAnsweredCorrectly));
            }
                }

        private WasTheQuestionAnsweredCorrectly wasTheQuestionAnsweredCorrectly = WasTheQuestionAnsweredCorrectly.WasNotAnswered;
        public WasTheQuestionAnsweredCorrectly WasTheQuestionAnsweredCorrectly
        {
            get => wasTheQuestionAnsweredCorrectly;
            set
            {
                wasTheQuestionAnsweredCorrectly = value;
                PropertyChanged += MathQuestionInt_PropertyChanged;
            }
        }

        private void MathQuestionInt_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            wasTheQuestionAnswered = WasTheQuestionAnswered.WasAnswered;
        }

        private int levelOfTheQuestion = 1;

        /// <summary>
        /// - AdditionTo10 = 1, //Level 1
        /// - SubtractionTo10, //Level 2
        /// - AddSubTo10, //Level 3 
        /// - AdditionTo20, //Level 4
        /// - SubtractionTo20, //Level 5
        /// - AddSubTo20 //Level 6
        /// </summary>
        public int LevelOfTheQuestion { 
            get => levelOfTheQuestion; 
            set
            {
                int previousLEvel = LevelOfTheQuestion;
                levelOfTheQuestion = value;
                OnPropertyChanged(nameof(LevelOfTheQuestion));
            }
                }
        public string TheQuestion { get; set; }
        public string TheAnswer { get; set; }

        public MathQuestionInt(int levelOfTheQuestion)
        {
            WasThisQuestionAnswered = WasTheQuestionAnswered.WasNotAnswered;
            WasTheQuestionAnsweredCorrectly = WasTheQuestionAnsweredCorrectly.WasNotAnswered;
            LevelOfTheQuestion = levelOfTheQuestion;
            TheQuestion = GenerateQuestion();
        }

        public MathQuestionInt()
        {
            WasThisQuestionAnswered = WasTheQuestionAnswered.WasNotAnswered;
            WasTheQuestionAnsweredCorrectly = WasTheQuestionAnsweredCorrectly.WasNotAnswered;
            LevelOfTheQuestion = 1;
            TheQuestion = GenerateQuestion();
        }

       

        int[] GenerateNumbers()
        {            
            if (LevelOfTheQuestion == 1 || LevelOfTheQuestion == 2)
            {
                return new int[] { GenerateNumberTo10(), GenerateNumberTo10() };
            }

            else
            {
                return new int[] { GenerateNumberTo20(), GenerateNumberTo20() };
            }
        }

        string GenerateOperator()
        {
            if (LevelOfTheQuestion == 1 || LevelOfTheQuestion == 4)
            {
                return "+";
            }
            else if (LevelOfTheQuestion == 2 || LevelOfTheQuestion == 5)
            {
                return "-";
            }
            else
            {
                Random rand = new Random();
                int myOperator = rand.Next(0, 1);
                if(myOperator == 1)
                {
                    return "+";                    
                }
                else
                {
                    return "-";
                }
            }
        }

        string GenerateQuestion()
        {
            int[] Numbers = GenerateNumbers();
            string theOperation = GenerateOperator();
            
            if (theOperation == "+")
            {
                TheAnswer = (Numbers[0] + Numbers[1]).ToString();                
            }
            else
            {
                TheAnswer = (Numbers[0] - Numbers[1]).ToString();
            }
            return Numbers[0].ToString() + GenerateOperator() + Numbers[1].ToString(); 
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public static int GenerateNumberTo10()
        {
            Random rand = new Random();
            return rand.Next(0, 10);
        }
        public static int GenerateNumberTo20()
        {
            Random rand = new Random();
            return rand.Next(0, 20);
        }
    }   

}
