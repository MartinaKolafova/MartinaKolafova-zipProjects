﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CzechitasProject
{
    /// <summary>
    /// Abstract class for pictures
    /// </summary>
    public abstract class PrintPicture : IPrint
    {
        /// <summary>
        /// Delete anything on the screen
        /// </summary>
        public void DeleteScreen()
        {
            Console.Clear();            
        }

        public virtual void Print(int startLeft, int startTop)
        {
        }
       
    }
}
