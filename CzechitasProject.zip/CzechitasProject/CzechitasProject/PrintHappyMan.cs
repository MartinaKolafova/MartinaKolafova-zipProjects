﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CzechitasProject
{
    /// <summary>
    /// 
    /// </summary>
    /// <param name="startLeft">Where printing of the whole man starts</param>
    /// <param name="startTop">Where printing of the whole man starts</param>
    public delegate void DeleteBodyPart(int startLeft, int startTop);

    public class PrintHappyMan : PrintPicture
    {
        /// <summary>
        /// Print the picture of a happy man in the console
        /// Recommanded: int startLeft = 30; int startTop = 10;
        /// </summary>
        public override void Print(int startLeft, int startTop)
        {
            Console.CursorVisible = false;
            Console.ForegroundColor = ConsoleColor.White;
            PrintHead(startLeft, startTop);  
            PrintBody(startLeft, startTop);
            PrintLegs(startLeft, startTop);            
            PrintArms(startLeft, startTop);
            PrintHandsUp(startLeft, startTop);
        }

        /// <summary>
        /// Print head of happy man
        /// </summary>
        /// <param name="startLeft">Where printing of the whole man starts</param>
        /// <param name="startTop">Where printing of the whole man starts</param>
        public void PrintHead(int startLeft, int startTop)
        {
            //Head
            Console.CursorLeft = startLeft;
            Console.CursorTop = startTop - 1;
            Console.Write("██████");
            Console.CursorLeft = startLeft;
            Console.CursorTop = startTop;
            Console.Write("██████");
            Console.CursorLeft = startLeft;
            Console.CursorTop = startTop + 1;
            Console.Write("██████");
            Console.CursorLeft = startLeft + 2;
            Console.CursorTop = startTop + 2;
            Console.Write("██");
        }

        /// <summary>
        /// Print body of happy man
        /// </summary>
        /// <param name="startLeft">Where printing of the whole man starts</param>
        /// <param name="startTop">Where printing of the whole man starts</param>
        public void PrintBody(int startLeft, int startTop)
        {
            //Body
            Console.CursorLeft = startLeft + 2;
            Console.CursorTop = startTop + 3;
            Console.Write("██");
            Console.CursorLeft = startLeft + 2;
            Console.CursorTop = startTop + 4;
            Console.Write("██");
            Console.CursorLeft = startLeft + 2;
            Console.CursorTop = startTop + 5;
            Console.Write("██");
            Console.CursorLeft = startLeft + 2;
            Console.CursorTop = startTop + 6;
            Console.Write("██");
        }

        /// <summary>
        /// Print legs of happy man
        /// </summary>
        /// <param name="startLeft">Where printing of the whole man starts</param>
        /// <param name="startTop">Where printing of the whole man starts</param>
        public void PrintLegs(int startLeft, int startTop)
        {
            //Legs
            Console.CursorLeft = startLeft;
            Console.CursorTop = startTop + 7;
            Console.Write("██");
            Console.CursorLeft = startLeft + 4;
            Console.CursorTop = startTop + 7;
            Console.Write("██");
            Console.CursorLeft = startLeft - 2;
            Console.CursorTop = startTop + 8;
            Console.Write("██");
            Console.CursorLeft = startLeft + 6;
            Console.CursorTop = startTop + 8;
            Console.Write("██");
            Console.CursorLeft = startLeft - 4;
            Console.CursorTop = startTop + 9;
            Console.Write("██");
            Console.CursorLeft = startLeft + 8;
            Console.CursorTop = startTop + 9;
            Console.Write("██");
            Console.CursorLeft = startLeft - 4;
            Console.CursorTop = startTop + 10;
            Console.Write("██");
            Console.CursorLeft = startLeft + 8;
            Console.CursorTop = startTop + 10;
            Console.Write("██");
            Console.CursorLeft = startLeft - 4;
            Console.CursorTop = startTop + 11;
            Console.Write("██");
            Console.CursorLeft = startLeft + 8;
            Console.CursorTop = startTop + 11;
            Console.Write("██");
            Console.CursorLeft = startLeft - 4;
            Console.CursorTop = startTop + 12;
            Console.Write("██");
            Console.CursorLeft = startLeft + 8;
            Console.CursorTop = startTop + 12;
            Console.Write("██");
            Console.CursorLeft = startLeft - 6;
            Console.CursorTop = startTop + 12;
            Console.Write("██");
            Console.CursorLeft = startLeft + 10;
            Console.CursorTop = startTop + 12;
            Console.Write("██");
        }

        /// <summary>
        /// Print arms of happy man
        /// </summary>
        /// <param name="startLeft">Where printing of the whole man starts</param>
        /// <param name="startTop">Where printing of the whole man starts</param>
        public void PrintArms(int startLeft, int startTop)
        {
            Console.CursorLeft = startLeft;
            Console.CursorTop = startTop + 3;
            Console.Write("██");
            Console.CursorLeft = startLeft + 4;
            Console.CursorTop = startTop + 3;
            Console.Write("██");
            Console.CursorLeft = startLeft - 2;
            Console.CursorTop = startTop + 3;
            Console.Write("██");
            Console.CursorLeft = startLeft + 6;
            Console.CursorTop = startTop + 3;
            Console.Write("██");
        }

        /// <summary>
        /// Print hands up of happy man
        /// </summary>
        /// <param name="startLeft">Where printing of the whole man starts</param>
        /// <param name="startTop">Where printing of the whole man starts</param>
        public void PrintHandsUp(int startLeft, int startTop)
        {
            Console.CursorLeft = startLeft - 4;
            Console.CursorTop = startTop + 2;
            Console.Write("██");
            Console.CursorLeft = startLeft + 8;
            Console.CursorTop = startTop + 2;
            Console.Write("██");
            Console.CursorLeft = startLeft - 6;
            Console.CursorTop = startTop + 1;
            Console.Write("██");
            Console.CursorLeft = startLeft + 10;
            Console.CursorTop = startTop + 1;
            Console.Write("██");
            Console.CursorLeft = startLeft - 6;
            Console.CursorTop = startTop;
            Console.Write("██");
            Console.CursorLeft = startLeft + 10;
            Console.CursorTop = startTop;
            Console.Write("██");
        }

        /// <summary>
        /// Print hands vertically
        /// </summary>
        /// <param name="startLeft">Where printing of the whole man starts</param>
        /// <param name="startTop">Where printing of the whole man starts</param>
        public void PrintHandsHorizontal(int startLeft, int startTop)
        {
            Console.CursorLeft = startLeft - 4;
            Console.CursorTop = startTop + 3;
            Console.Write("██");
            Console.CursorLeft = startLeft + 8;
            Console.CursorTop = startTop + 3;
            Console.Write("██");
            Console.CursorLeft = startLeft - 6;
            Console.CursorTop = startTop + 3;
            Console.Write("██");
            Console.CursorLeft = startLeft + 10;
            Console.CursorTop = startTop + 3;
            Console.Write("██");
        }

        /// <summary>
        /// Delete the body parts = print it in background color 
        /// </summary>
        /// <param name="startLeft">Where printing of the whole man starts</param>
        /// <param name="startTop">Where printing of the whole man starts</param>
        /// <param name="deleteBodyPart">The printing function of a body part to be deleted</param>
        public void DeleteBodyPart(int startLeft, int startTop, DeleteBodyPart deleteBodyPart)
        {
            Console.ForegroundColor = Console.BackgroundColor;
            deleteBodyPart(startLeft, startTop);
            Console.ForegroundColor = ConsoleColor.White;
        }

        /// <summary>
        /// Animate the hands of the happy man
        /// </summary>
        /// <param name="startLeft">Where printing of the whole man starts</param>
        /// <param name="startTop"Where printing of the whole man starts></param>
        public void AnimateHappyMan(int startLeft, int startTop)
        {
            Print(startLeft, startTop);
            int count = 0;
            do
            {
                DeleteBodyPart(startLeft, startTop, PrintHandsUp);
                PrintHandsHorizontal(startLeft, startTop);
                Thread.Sleep(200);
                DeleteBodyPart(startLeft, startTop, PrintHandsHorizontal);
                PrintHandsUp(startLeft, startTop);
                Thread.Sleep(200);
                count++;
            } while (count < 5);           
            
        }

        /// <summary>
        /// Print the whole animation including deleting it at the end
        /// </summary>
        /// <param name="startLeft"></param>
        /// <param name="startTop"></param>
        public void HappyManAnimationInTheGame(int startLeft, int startTop)
        {
            DeleteScreen();
            Print(startLeft, startTop);
            AnimateHappyMan(30, 10);
            DeleteScreen();
        }
    }
}
