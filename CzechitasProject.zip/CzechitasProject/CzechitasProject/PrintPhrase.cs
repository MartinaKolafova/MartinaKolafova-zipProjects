﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CzechitasProject
{
    /// <summary>
    /// Set of phrases - to be the same
    /// </summary>
    public static class PrintPhrase 
    {
        
        /// <summary>
        /// Print the phrase
        /// </summary>
        public static void PrintWasOK()
        {
            Console.WriteLine("Správně!");
        }

        /// <summary>
        /// Print number of correctly answered question in this game
        /// </summary>
        /// <param name="numberOfCorrectAnswerInThisLevel"></param>
        public static void PrintNumberOfCorrectQuestionInThisLevel(int numberOfCorrectAnswerInThisLevel)
        {
            Console.WriteLine($"Počet tvých správných odpovědí v tomto levelu je prozatím: {numberOfCorrectAnswerInThisLevel}");
        }
    }
}
