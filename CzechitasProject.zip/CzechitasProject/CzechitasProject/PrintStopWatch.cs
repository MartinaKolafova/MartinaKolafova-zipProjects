﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CzechitasProject
{
    public class PrintStopWatch : PrintPicture
    {       
        public override void Print(int startLeft, int startTop)
        {
            ;
        }

        public void PrintScale(int startLeft, int startTop)
        {
            int level = 10;
            int cursorLeft = startLeft; 
            int cursorTop = startTop;
            Console.CursorLeft = cursorLeft;            
            Console.CursorTop = cursorTop;
            for (int i = 0; i < level; i++)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                cursorTop += 1;
                Console.CursorLeft = cursorLeft;
                Console.CursorTop = cursorTop;
                Console.Write("██");                
                //cursorLeft;
                
                Thread.Sleep(2000);
            }
        }
    }
}
