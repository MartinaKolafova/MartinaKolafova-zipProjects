﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Czechitas_projekt_zoo
{
    public static class PrintHelp
    {
        /// <summary>
        /// Display program help
        /// </summary>
        public static void PrintThisHelp()
        {
            Console.WriteLine("0...Sponzoruj - dá na výběr zvíře a částku. Minimální částka je 10 peněz.");
            Console.WriteLine("1...Pusť lva. Lev sežere jednoho ošetřovatele.");
            Console.WriteLine("2...Vypiš zvířata v zoo.");
            Console.WriteLine("3...Seřaď zvířata od nejbohatšího.");
            Console.WriteLine("4...Zaměstnej nového ošetřovatele.");
            Console.WriteLine("5...Zjisti vystoupení delfína.");
            Console.WriteLine("6...Daruj zoo zvíře.");
            Console.WriteLine("h...Nápověda");
            Console.WriteLine("Esc....Konec");
        }
    }
}
