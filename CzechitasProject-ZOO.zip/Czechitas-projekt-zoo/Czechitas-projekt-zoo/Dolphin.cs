﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Czechitas_projekt_zoo
{
    class Dolphin : Animal
    {
        /// <summary>
        /// The time of the performance of a Dolphin
        /// Default set to 15
        /// </summary>
        public DateTime NextPerformanceTime { get; private set; } = DateTime.Today.AddHours(15);

        public Dolphin(string name) : base(name)
        {

        }
        
        public Dolphin(DateTime nextPerformanceTime)
        {
            NextPerformanceTime = nextPerformanceTime;
        }      

        public Dolphin(DateTime nextPerformanceTime, string name, decimal money)
        {
            NextPerformanceTime = nextPerformanceTime;
            Name = name;
            MoneyInTheAccount = money;
        }

        /// <summary>
        /// Print time of next performance
        /// </summary>
        public void PrintTimeOfDolphinsNestPerformance()
        {
            Console.WriteLine($"Delfín {Name} má další vystoupení v {NextPerformanceTime.ToShortTimeString()}.");
        }
    }
}
