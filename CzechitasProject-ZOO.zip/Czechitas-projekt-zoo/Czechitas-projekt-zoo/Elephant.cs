﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Czechitas_projekt_zoo
{
    public class Elephant : Animal
    {
        public Elephant(string name) : base(name)
        {

        }
    }
}
