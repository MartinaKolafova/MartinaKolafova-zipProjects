﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Czechitas_projekt_zoo
{
    //

    public abstract class Animal
    {
        /// <summary>
        /// Name of the animal
        /// </summary>
        public string Name { get; set; }

        private decimal moneyInTheAccount = 0;

        /// <summary>
        /// Money in the account of the animal
        /// When money are added to the account, Number of donations is increased by 1
        /// </summary>
        public decimal MoneyInTheAccount
        {
            get
            {
                NumberOfDonations++;
                return moneyInTheAccount;
            }

            protected set
            {
                moneyInTheAccount = value;
            }
        }

        /// <summary>
        /// Number of donations for this animal
        /// </summary>
        public int NumberOfDonations { get; protected set; } = 0;

        public Animal()
        {
            Name = "Nikola";
            moneyInTheAccount = 0;
        }

        /// <summary>
        /// Animal without money
        /// </summary>
        /// <param name="name"></param>
        public Animal(string name)
        {
            Name = name;
            moneyInTheAccount = 0;
        }

        /// <summary>
        /// Animal with name and money
        /// </summary>
        /// <param name="name">Name of the animal</param>
        /// <param name="money">Money in the account</param>
        public Animal(string name, decimal money)
        {
            Name = name;
            moneyInTheAccount = money;
        }

        /// <summary>
        /// Add money in the account
        /// </summary>
        /// <param name="money"></param>
        public void Sponsor(decimal money)
        {
            if (money >= 10)
            {
                MoneyInTheAccount += money;
                if (money <= 100)
                {
                    Console.WriteLine("Děkujeme za symbolickou částku!");
                }

                else if (money > 100 && money <= 1000)
                {
                    Console.WriteLine("Děkujeme za příjemné přilepšení");
                }

                else if (money > 1000 && money <= 1000000)
                {
                    Console.WriteLine("Děkujeme za štědrý dar!");
                }

                else
                {
                    Console.WriteLine($"Děkujeme! Částku {money} jsme opravdu nečekali a vyrazila nám dech!");
                }
            }
            else
            {
                Console.WriteLine("Připsaná částka musí být alespoň symbolická částka 10 Kč.");
            }
        }

        /// <summary>
        /// Buy food using the money of the particular animal
        /// </summary>
        /// <param name="money">Money to be spent</param>
        public void BuyFood(decimal money)
        {
            if (money < MoneyInTheAccount)
            {
                MoneyInTheAccount -= money;
                Console.WriteLine($"Nakoupili jsme žrádlo pro {this.ToString()} za {money} Kč.");
            }
            else
            {
                decimal sumOfMoneySpent = MoneyInTheAccount;
                MoneyInTheAccount = 0;
                if (sumOfMoneySpent == 0)
                {
                    Console.WriteLine("Účet byl vybílený, zvířeti musíte nakoupit žrádlo z rozpočtu zoo.");
                }
                else
                {
                    Console.WriteLine($"Nakoupili jsme žrádlo pro {this.ToString()} za {sumOfMoneySpent} Kč.");
                }
            }
        }

        /// <summary>
        /// Returns the name of class derived from animal 
        /// </summary>
        /// <returns>Name of the class in CZ</returns>
        public override string ToString()
        {
            switch (GetType().Name.ToString())
            {
                case "Dolphin":
                    return "delfín";
                case "Elephant":
                    return "slon";
                case "Lion":
                    return "lev";
                case "Zebra":
                    return "zebra";
                default:
                    return "zvíře";
            }
        }
    }
}
