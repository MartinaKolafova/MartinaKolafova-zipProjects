﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Czechitas_projekt_zoo
{
    static class TestingZoo
    {
        public static Zoo TestThisZoo()
        {
            Zoo testedZoo = new Zoo();
            List<Animal> animals = new List<Animal>() { new Dolphin(DateTime.Today.AddHours(16)), new Dolphin(DateTime.Today.AddHours(10), "Willy", 100m), new Lion("Punťa"), new Zebra("Mařenka"), new Zebra("Karolínka"), new Dolphin(DateTime.Today.AddHours(16), "Wil", 500m), new Elephant("Smraďoch") };
            List<Keeper> keepers = new List<Keeper>() { new Keeper("Pepa"), new Keeper("Karel"), new Keeper("Adéla") };
            testedZoo.AnimalsInTheZoo = animals;
            testedZoo.KeepersInTheZoo = keepers;
            return testedZoo;
        }
    }
}
