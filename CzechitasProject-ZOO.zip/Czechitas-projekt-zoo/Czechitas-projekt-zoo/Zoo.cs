﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Martina Kolafová, Czechitas projekt
/// </summary>
namespace Czechitas_projekt_zoo
{
    public class Zoo
    {
        /// <summary>
        /// Keepers in the zoo
        /// </summary>
        public List<Keeper> KeepersInTheZoo { get; set; }       
       
        /// <summary>
        /// Animals in the zoo
        /// </summary>
        public List<Animal> AnimalsInTheZoo { get; set; }

        /// <summary>
        /// Empty zoo
        /// </summary>
        public Zoo()
        {
            AnimalsInTheZoo = new List<Animal>();
            KeepersInTheZoo = new List<Keeper>();
        }


        /// <summary>
        /// Sort the animals, the richest first
        /// </summary>
        public void SortAnimalsRichestFirst()
        {
            for (int j = 0; j < AnimalsInTheZoo.Count() - 1; j++)
            {
                for (int i = 0; i < AnimalsInTheZoo.Count() - 1; i++)
                {
                    if (AnimalsInTheZoo[i].MoneyInTheAccount < AnimalsInTheZoo[i + 1].MoneyInTheAccount)
                    {
                        Animal helpingAnimal = AnimalsInTheZoo[i];
                        AnimalsInTheZoo[i] = AnimalsInTheZoo[i + 1];
                        AnimalsInTheZoo[i + 1] = helpingAnimal;
                    }
                }
            }
        }

        /// <summary>
        /// Print all the animale in the zoo
        /// </summary>
        public void PrintAnimals()
        {
            foreach (Animal a in AnimalsInTheZoo)
            {
                Console.WriteLine($"{a.Name} je {a.ToString()} a má na účtu {a.MoneyInTheAccount} peněz.");
            }
        }

        /// <summary>
        /// Add new keeper in the zoo
        /// Enlarges the List KeepersInTheZoo by 1
        /// </summary>
        public void HireNewKeeper()
        {
            Console.WriteLine("Chceš zaměstnat nového ošetřovatele.");
            string newKeepersName = AskUser.AskUserForString("Jak se má jmenovat", "Nikola");
            KeepersInTheZoo.Add(new Keeper(newKeepersName));
            Console.WriteLine($"Byl zaměstnán ošetřovatel {newKeepersName}.");
        }

        /// <summary>
        /// Print time of performance for each dolphin
        /// </summary>
        public void FindDolphinsPrinPerformanceTime()
        {
            foreach (Animal a in AnimalsInTheZoo)
            {
                if (a is Dolphin)
                {
                    Dolphin dolphin = (Dolphin)a;
                    dolphin.PrintTimeOfDolphinsNestPerformance();
                }
            }
        }

        /// <summary>
        /// Add new animal in the zoo
        /// </summary>
        /// <returns>True if animal was added successfully</returns>
        public bool AddNewAnimal()
        {
            Console.WriteLine("Děkujeme, že jste se rozhodli koupit zvíře pro naši zoo!");
            string animalsName = AskUser.AskUserForString("Jak se má jmenovat", "Nikola");
            Console.WriteLine("Jaké zvíře byste nám rádi pořídili?");
            Console.WriteLine("Máme zařízeny výběhy pro následující zvířeta:");
            ConsoleKeyInfo key = AskUser.ChooseFromAnimals();
            Console.WriteLine();
            if (key.Key == ConsoleKey.NumPad1 || key.Key == ConsoleKey.D1)
            {
                Dolphin dolphin = new Dolphin(animalsName);
                AnimalsInTheZoo.Add(dolphin);                
            }
            else if (key.Key == ConsoleKey.NumPad2 || key.Key == ConsoleKey.D2)
            {
                Elephant elephant = new Elephant(animalsName);
                AnimalsInTheZoo.Add(elephant);
            }
            else if (key.Key == ConsoleKey.NumPad3 || key.Key == ConsoleKey.D3)
            {
                Lion lion = new Lion(animalsName);
                AnimalsInTheZoo.Add(lion);
            }
            else if (key.Key == ConsoleKey.NumPad4 || key.Key == ConsoleKey.D4)
            {
                Zebra zebra = new Zebra(animalsName);
                AnimalsInTheZoo.Add(zebra);
            }
            else if (key.Key == ConsoleKey.NumPad0 || key.Key == ConsoleKey.D0)
            {
                Console.WriteLine("Nevadí, můžeš nám koupit zvíře jindy.");
                return false;
            }
            else
            {
                Console.WriteLine("Bohužel pro jiné zvíře nemáme ubytovací kapacity.");
                return false;
            }
            Console.WriteLine($"Bylo přidáno nové zvíře, a to {AnimalsInTheZoo.Last().ToString()} jménem {AnimalsInTheZoo.Last().Name}.");
            return true;
        }

        /// <summary>
        /// Let the lion out of the cage. It eats one keeper, if there is any keeper.
        /// </summary>
        public void LetTheLionOutOfTheCage()
        {
            if (KeepersInTheZoo.Count() > 0)
            {
                foreach (Animal a in AnimalsInTheZoo)
                {
                    if (a is Lion)
                    {
                        Lion lion = (Lion)a;
                        lion.EatAKeeper(KeepersInTheZoo);
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Ask for amount of money, name and animal species the user would like to sponsor
        /// </summary>
        public void AddMoneyToAccountOfChosenAnimal()
        {
            decimal moneyForTheAnimal = 0;
            while (moneyForTheAnimal <= 0)
            {
                moneyForTheAnimal = AskUser.AskUserForSumOfMoney(10);
            }
            Console.WriteLine("V zoo máme tato zvířata:");
            PrintAnimals();
            Console.WriteLine("Jaké zvíře jste si vybrali pro sponzoring? Napište jeho jméno.");
            string animalToBeSponsored = Console.ReadLine();
            Animal chosenAnimal = ChooseAnimalFromTheListOfAnimals(animalToBeSponsored);
            if (chosenAnimal != null)
            {
                for (int i = 0; i < AnimalsInTheZoo.Count(); i++)
                {
                    if (AnimalsInTheZoo[i].Name == chosenAnimal.Name && AnimalsInTheZoo[i].ToString() == chosenAnimal.ToString())
                    {
                        Console.WriteLine();
                        AnimalsInTheZoo[i].Sponsor(moneyForTheAnimal);
                        Console.WriteLine($"{ AnimalsInTheZoo[i].Name} má nyní na účtu {AnimalsInTheZoo[i].MoneyInTheAccount} peněz.");
                    }
                }
            }
            else
            {
                Console.WriteLine("Bohužel toto zvíře v zoo nemáme.");
            }
        }       

        /// <summary>
        /// Choose animal with the same name from animals in the zoo. 
        /// </summary>
        /// <param name="animalsName">Name of animal you are looking for</param>
        /// <returns>Animal with the same name. </returns>
        public Animal ChooseAnimalFromTheListOfAnimals(string animalsName)
        {
            List<Animal> animalsWithTheName = new List<Animal>();
            //Add animals with the sam name to the new list
            animalsWithTheName.Add(AnimalsInTheZoo.Find(x => x.Name.ToLower().Equals(animalsName.ToLower())));
            if (animalsWithTheName.Count()==0)
            {
                return null;
            }
            else if(animalsWithTheName.Count()==1)
            {
                return animalsWithTheName[0];
            }
            foreach (Animal a in animalsWithTheName)
            {
                Console.WriteLine($"Je {a.ToString()} zvíře, které jste si vybrali?");
                ConsoleKeyInfo key = Console.ReadKey();
                if (key.Key == ConsoleKey.Enter)
                {
                    return a;
                }
            }
            return null;
        }

    }
}
