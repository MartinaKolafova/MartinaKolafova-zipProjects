﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Czechitas_projekt_zoo
{
    /// <summary>
    /// Keeper takes care of the animals in the zoo. He has a name as property.
    /// </summary>
    public class Keeper
    {
        public string Name { get; set; }

        public Keeper(string name)
        {
            Name = name;
        }
    }
}
