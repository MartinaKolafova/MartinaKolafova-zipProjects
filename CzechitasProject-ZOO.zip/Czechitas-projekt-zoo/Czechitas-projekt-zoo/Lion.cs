﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Czechitas_projekt_zoo
{
    public class Lion : Animal
    {

        public Lion(string name) : base(name)
        {

        }

        public void EatAKeeper(List<Keeper> keepers)
        {
            string nameOfTheKeeper = string.Empty;

            if(keepers.Count() > 0)
            {
                nameOfTheKeeper = keepers[0].Name;
                keepers.RemoveAt(0);                
                Console.WriteLine($"Sežral jsem ošetřovatele jménem {nameOfTheKeeper}. Byla to pochoutka!");
            }
            else
            {

            }

        }
    }
}
