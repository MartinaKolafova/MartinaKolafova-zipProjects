﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Czechitas_projekt_zoo
{
    public static class AskUser
    {
        /// <summary>
        /// Ask user for string, min 3 chars, max 20 chars, no digits
        /// </summary>
        /// <returns>string; if the user is unable to enter input for 3 times, defaultAnswer is given</returns>
        public static string AskUserForString(string question, string defaultAnswer)
        {            
            Console.WriteLine(question); //"Jak se má jmenovat?"
            string stringFromUser = string.Empty;

            int numberOfAttempts = 0;

            while (numberOfAttempts < 3)
            {
                stringFromUser = Console.ReadLine();
                bool containsNumber = false;
                foreach(char c in stringFromUser)
                {
                    if (int.TryParse(c.ToString(), out int _result))
                    {                        
                        containsNumber = true;                        
                    }
                }

                if (containsNumber)
                {
                    Console.WriteLine($"{stringFromUser} není povoleno, protože obsahuje číslice.");
                    numberOfAttempts++;
                }

                else
                {
                    if (stringFromUser.Length < 3)
                    {
                        Console.WriteLine($"Ale no tak! {stringFromUser} je to příliš krátké.");
                        numberOfAttempts++;
                    }
                    else if (stringFromUser.Length > 20)
                    {
                        Console.WriteLine($"Ale no tak! {stringFromUser} je to příliš dlouhé.");
                        numberOfAttempts++;
                    }
                    else
                    {
                        Console.WriteLine("");
                        return stringFromUser;
                    }
                }
            }
            stringFromUser = defaultAnswer; //"Nikola"
            Console.WriteLine($"Pardon, ale ani na třetí pokus se zadání nepodařilo. Bude se jmenovat {stringFromUser}");
            return stringFromUser;
        }

        public static decimal AskUserForSumOfMoney(decimal minimum)
        {
            Console.WriteLine("Děkujeme, že jste se rozhodli sponzorovat naši zoo.");
            Console.WriteLine("Jakou částku si přejete věnovat?");
            if (decimal.TryParse(Console.ReadLine(), out decimal sumOfMoney))
            {
                if (sumOfMoney >= minimum)
                {
                    Console.WriteLine($"Rozhodli jste se věnovat {sumOfMoney} peněz");
                    return sumOfMoney;
                }
                else
                {
                    Console.WriteLine($"Minimální částka je: {minimum} peněz.");
                    return 0;
                }
            }
            else
            {
                Console.WriteLine("Částka musí být deklarovaná jako číslo.");
                return 0;
            }
        }

        /// <summary>
        /// Print all types of animal available in the zoo and ask user for his choice
        /// </summary>
        /// <returns>ConsoleKeyInfo pressed by user</returns>
        public static ConsoleKeyInfo ChooseFromAnimals()
        {
            Console.WriteLine("1...Delfín");
            Console.WriteLine("2...Slon");
            Console.WriteLine("3...Lev");
            Console.WriteLine("4...Zebra");
            Console.WriteLine("0...Nic z uvedeného.");
            return Console.ReadKey();
        }
    }
}
