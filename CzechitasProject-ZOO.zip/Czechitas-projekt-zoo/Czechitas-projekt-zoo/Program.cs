﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Czechitas_projekt_zoo
{
    class Program
    {
        static void Main(string[] args)
        {            
            Console.WriteLine("Vítejte v nové zoo! ");
            Console.WriteLine("Následujícími klávesami můžete ovládat zoo:");
            Zoo zoo = TestingZoo.TestThisZoo();            
            PrintHelp.PrintThisHelp();
            ConsoleKeyInfo key;

            do
            {
                //If number of keepers is 0, the zoo must close
                if (zoo.KeepersInTheZoo.Count() == 0)
                {
                    Console.WriteLine("Došli ošetřovatelé!");
                    break;
                }
                //Ask user for input                
                Console.WriteLine("Co bys rád udělal dál? Zmáčkni tlačítko 0-6!");
                key = Console.ReadKey();
                Console.WriteLine(" ");

                //Play the game
                switch (key.Key)
                {
                    case ConsoleKey.NumPad0:
                    case ConsoleKey.D0:
                        zoo.AddMoneyToAccountOfChosenAnimal();
                        break;
                    case ConsoleKey.NumPad1:
                    case ConsoleKey.D1:
                        zoo.LetTheLionOutOfTheCage();
                        break;
                    case ConsoleKey.NumPad2:
                    case ConsoleKey.D2:
                        zoo.PrintAnimals();
                        break;
                    case ConsoleKey.NumPad3:
                    case ConsoleKey.D3:
                        zoo.SortAnimalsRichestFirst();
                        zoo.PrintAnimals();
                        break;
                    case ConsoleKey.NumPad4:
                    case ConsoleKey.D4:
                        zoo.HireNewKeeper();                        
                        break;
                    case ConsoleKey.NumPad5:
                    case ConsoleKey.D5:
                        zoo.FindDolphinsPrinPerformanceTime();
                        break;
                    case ConsoleKey.NumPad6:
                    case ConsoleKey.D6:
                        zoo.AddNewAnimal();
                        break;
                    case ConsoleKey.H:
                        PrintHelp.PrintThisHelp();
                        break;
                }                
            }            
            while (key.Key != ConsoleKey.Escape);

            Console.WriteLine(" ");
            Console.WriteLine("Zoo zavřela! Na shledanou!");
            Thread.Sleep(5000);
        }
    }
}
